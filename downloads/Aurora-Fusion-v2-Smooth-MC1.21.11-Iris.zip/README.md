# Aurora Fusion Shaders v2 Smooth

An original lightweight-to-balanced shader pack for **Minecraft Java 1.21.11 + Iris**.

## New in v2 Smooth
- Sharpness option in Post Processing
- Cloud types: Vanilla / Smooth / Puffy / Flat, plus cloud opacity, brightness, height, speed, and optional cloud shadows
- Water reflection options with sky reflection plus screen-space reflections on Balanced/Ultra
- Water wave strength, opacity, reflection strength, and shore foam controls
- Rainbow modes: Off / After Rain / Always + Double
- Shadow darkness and shadow bias controls
- Smoother distance-faded water normals to reduce sparkle/shimmer
- Performance / Balanced / Ultra profiles updated for the new options

## Features
- Sun/moon shadows with PCF softening and distance fade
- Warm daylight, blue moonlight, and block-light tinting
- Gradient sky with twilight glow, custom fog blending, and height-fog accent
- Animated water with procedural normals, fresnel sky reflection, screen-space reflection, foam, and sun glint
- Waving leaves/plants, lava/emissive boost for selected bright blocks
- ACES-style tonemapping, saturation/contrast controls, vignette, sharpness, and dithering
- Optional Iris chunk fade-in support (`FADE_VARIABLE`)

## Install
1. Install Minecraft Java 1.21.11 with Iris 1.10.8 and Sodium 0.8.14.
2. Copy this pack ZIP into `.minecraft/shaderpacks/`.
3. Select **Aurora Fusion** in Video Settings -> Shader Packs.

## Notes
The shader code in this pack was written for this project. Feature inspiration comes from common shader-pack ideas and the provided screenshots; no third-party shader code or textures are bundled.
