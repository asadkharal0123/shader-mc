/* Foliage motion. Included only by terrain/shadow vertex programs. */
#ifdef VERTEX
attribute vec4 mc_Entity;
attribute vec3 at_midBlock;
attribute vec2 mc_midTexCoord;

vec3 applyWaving(vec3 pos) {
    #if defined(WAVING_FOLIAGE) && (defined(PROGRAM_TERRAIN) || defined(PROGRAM_SHADOW))
        int blockId = int(mc_Entity.x + 0.5);
        vec3 worldAbs = pos + cameraPosition;
        float t = frameTimeCounter;

        if (blockId == 1001) {
            float phase = worldAbs.x * 0.45 + worldAbs.z * 0.38 + worldAbs.y * 0.22;
            pos.x += sin(t * 1.15 + phase) * 0.035;
            pos.z += cos(t * 0.95 + phase * 1.31) * 0.035;
        } else if (blockId == 1002 || blockId == 1003) {
            float topWeight = at_midBlock.y > 0.0 ? 1.0 : 0.12;
            float phase = worldAbs.x * 0.85 + worldAbs.z * 0.70;
            float sway = (sin(t * 1.7 + phase) + 0.45 * sin(t * 2.9 + phase * 1.7)) * 0.075 * topWeight;
            pos.x += sway;
            pos.z += sway * 0.62;
        }
    #endif
    return pos;
}
#endif
