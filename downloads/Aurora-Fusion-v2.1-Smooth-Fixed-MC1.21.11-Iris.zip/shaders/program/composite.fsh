#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

varying vec2 texcoord;

vec3 viewPosFromDepth(vec2 uv, float depth) {
    vec4 clipPos = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return clipPos.xyz / clipPos.w;
}

vec2 screenPosFromView(vec3 viewPos) {
    vec4 clipPos = gbufferProjection * vec4(viewPos, 1.0);
    return clipPos.xy / clipPos.w * 0.5 + 0.5;
}

vec3 screenSpaceReflection(vec3 viewPos, vec3 viewNormal, vec3 fallbackColor) {
    #if WATER_REFLECTIONS == 0
        return fallbackColor;
    #else
        vec3 reflectDir = reflect(normalize(viewPos), viewNormal);
        if (reflectDir.z > 0.35) return fallbackColor;

        #if WATER_REFLECTIONS == 2
            const int stepCount = 28;
        #else
            const int stepCount = 16;
        #endif

        float rayLength = 0.10;
        for (int i = 0; i < 28; i++) {
            if (i >= stepCount) break;
            rayLength *= 1.24;
            vec3 rayPos = viewPos + reflectDir * rayLength;
            if (rayPos.z > -0.05) break;

            vec2 hitUV = screenPosFromView(rayPos);
            if (hitUV.x < 0.001 || hitUV.x > 0.999 || hitUV.y < 0.001 || hitUV.y > 0.999) break;

            float sceneDepth = texture2D(depthtex1, hitUV).r;
            if (sceneDepth >= 0.9999) continue;

            vec3 scenePos = viewPosFromDepth(hitUV, sceneDepth);
            float depthDiff = rayPos.z - scenePos.z;
            float thickness = 0.20 + rayLength * 0.025;
            if (depthDiff < 0.0 && depthDiff > -thickness) {
                vec2 edgeDelta = abs(hitUV - 0.5) * 2.0;
                float edgeFade = 1.0 - smoothstep(0.78, 1.0, max(edgeDelta.x, edgeDelta.y));
                return mix(fallbackColor, texture2D(colortex0, hitUV).rgb, edgeFade);
            }
        }

        return fallbackColor;
    #endif
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    vec4 waterData = texture2D(colortex1, texcoord);

    if (waterData.a > 0.003) {
        float surfaceDepth = texture2D(depthtex0, texcoord).r;
        if (surfaceDepth < 0.9999) {
            vec3 surfaceViewPos = viewPosFromDepth(texcoord, surfaceDepth);
            vec3 surfaceViewNormal = normalize(waterData.rgb * 2.0 - 1.0);

            #if WATER_REFLECTIONS > 0
                vec3 reflectionColor = screenSpaceReflection(surfaceViewPos, surfaceViewNormal, color);
                color = mix(color, reflectionColor, clamp(waterData.a * 0.90, 0.0, 1.0));
            #endif

            float opaqueDepth = texture2D(depthtex1, texcoord).r;
            if (opaqueDepth < 0.9999 && WATER_FOAM_STRENGTH > 0.001) {
                vec3 opaqueViewPos = viewPosFromDepth(texcoord, opaqueDepth);
                float waterThickness = distance(surfaceViewPos, opaqueViewPos);
                float foamBand = 1.0 - smoothstep(0.03, 0.65, waterThickness);
                vec3 surfaceWorldPos = (gbufferModelViewInverse * vec4(surfaceViewPos, 1.0)).xyz + cameraPosition;
                float foamNoise = valueNoise2(surfaceWorldPos.xz * 2.30 + vec2(frameTimeCounter * 0.35, -frameTimeCounter * 0.22));
                float foam = foamBand * smoothstep(0.45, 0.85, foamNoise) * WATER_FOAM_STRENGTH;
                vec3 foamColor = vec3(0.85, 0.92, 1.00) * (0.35 + 0.65 * getDayFactor());
                color = mix(color, foamColor, clamp(foam, 0.0, 1.0));
            }
        }
    }

    gl_FragData[0] = vec4(color, 1.0);
}
