#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#if defined(PROGRAM_TERRAIN)
    #include "/lib/waving.glsl"
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;
varying float vChunkFade;

void main() {
    vec3 pos = gl_Vertex.xyz;

    #if defined(PROGRAM_TERRAIN)
        vBlockId = mc_Entity.x;
        pos = applyWaving(pos);
    #else
        vBlockId = 0.0;
    #endif

    vec4 viewPos = gl_ModelViewMatrix * vec4(pos, 1.0);
    vViewPos = viewPos.xyz;
    vWorldPos = (gbufferModelViewInverse * viewPos).xyz;
    vWorldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;

    #if defined(PROGRAM_TERRAIN) && defined(IRIS_FEATURE_FADE_VARIABLE)
        vChunkFade = mc_chunkFade;
    #else
        vChunkFade = 1.0;
    #endif

    gl_Position = gl_ProjectionMatrix * viewPos;
}
