#include "/lib/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec4 vColor;

void main() {
    #if defined(PROGRAM_SHADOW_WATER)
        discard;
    #endif
    float alpha = texture2D(gtexture, texcoord).a * vColor.a;
    if (alpha < alphaTestRef) discard;
    gl_FragData[0] = vec4(1.0);
}
