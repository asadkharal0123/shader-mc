#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec3 acesApprox(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

vec3 gradeColor(vec3 hdrColor, vec2 uv) {
    vec3 graded = max(hdrColor, vec3(0.0)) * EXPOSURE;
    graded = acesApprox(graded);
    graded = toGamma(graded);

    float lum = luminance(graded);
    graded = mix(vec3(lum), graded, SATURATION);
    graded = (graded - 0.5) * CONTRAST + 0.5;

    vec2 centeredUV = uv * 2.0 - 1.0;
    float vig = 1.0 - VIGNETTE_STRENGTH * smoothstep(0.35, 1.25, dot(centeredUV, centeredUV));
    graded *= vig;
    return graded;
}

void main() {
    vec3 color = gradeColor(texture2D(colortex0, texcoord).rgb, texcoord);

    if (SHARPNESS > 0.001) {
        vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
        vec3 cLeft = gradeColor(texture2D(colortex0, texcoord + vec2(-texel.x, 0.0)).rgb, texcoord);
        vec3 cRight = gradeColor(texture2D(colortex0, texcoord + vec2(texel.x, 0.0)).rgb, texcoord);
        vec3 cDown = gradeColor(texture2D(colortex0, texcoord + vec2(0.0, -texel.y)).rgb, texcoord);
        vec3 cUp = gradeColor(texture2D(colortex0, texcoord + vec2(0.0, texel.y)).rgb, texcoord);
        vec3 neighborAverage = (cLeft + cRight + cDown + cUp) * 0.25;
        vec3 localMin = min(color, min(min(cLeft, cRight), min(cDown, cUp)));
        vec3 localMax = max(color, max(max(cLeft, cRight), max(cDown, cUp)));
        vec3 sharpened = color + (color - neighborAverage) * (SHARPNESS * 0.85);
        color = clamp(sharpened, localMin, localMax);
    }

    color += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
