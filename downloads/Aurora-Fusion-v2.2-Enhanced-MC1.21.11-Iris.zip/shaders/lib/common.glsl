/* Shared helpers and uniforms for Aurora Fusion. */

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform float fogStart;
uniform float fogEnd;
uniform float fogDensity;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float wetness;
uniform int isEyeInWater;
uniform int worldTime;
uniform float alphaTestRef;
uniform vec4 entityColor;

#ifdef FRAGMENT
uniform sampler2D gtexture;
uniform sampler2D shadowtex0;
#endif

float saturate1(float x) { return clamp(x, 0.0, 1.0); }
vec3 saturate3(vec3 x) { return clamp(x, vec3(0.0), vec3(1.0)); }
float luminance(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 toLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 toGamma(vec3 c) { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float valueNoise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x),
        mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x),
        u.y
    );
}

float fbm2(vec2 p) {
    float v = 0.0;
    float a = 0.55;
    for (int i = 0; i < 3; i++) {
        v += valueNoise2(p) * a;
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return v;
}

vec2 auroraOctEncode(vec3 n) {
    float denom = max(abs(n.x) + abs(n.y) + abs(n.z), 0.0001);
    n /= denom;
    vec2 uv = n.xz;
    if (n.y < 0.0) {
        vec2 s = sign(uv);
        s.x = s.x == 0.0 ? 1.0 : s.x;
        s.y = s.y == 0.0 ? 1.0 : s.y;
        uv = (vec2(1.0) - abs(uv.yx)) * s;
    }
    return uv * 0.5 + 0.5;
}

float auroraStars(vec3 dir, float amount) {
    if (amount < 0.01) return 0.0;
    float amt = clamp(amount, 0.0, 2.0);
    vec2 uv = auroraOctEncode(normalize(dir));
    float grid = 42.0 + amt * 34.0;
    vec2 cell = floor(uv * grid);
    vec2 local = fract(uv * grid);
    float h1 = hash12(cell * 1.71 + vec2(13.7, 57.3));
    float h2 = hash12(cell * 2.33 + vec2(91.7, 17.9));
    float h3 = hash12(cell * 0.91 + vec2(41.0, 3.0));
    vec2 center = vec2(0.18 + 0.64 * h1, 0.18 + 0.64 * h2);
    float point = smoothstep(0.18, 0.02, distance(local, center));
    float threshold = 1.0 - 0.055 * amt - 0.025 * amt * amt;
    float twinkle = 0.78 + 0.22 * sin(frameTimeCounter * (1.0 + h1 * 3.0) + h1 * 91.0);
    return point * step(threshold, h3) * twinkle;
}

vec3 auroraEndTint() {
    if (END_FOG_COLOR == 1) return vec3(0.012, 0.035, 0.115);
    if (END_FOG_COLOR == 2) return vec3(0.010, 0.105, 0.085);
    if (END_FOG_COLOR == 3) return vec3(0.115, 0.020, 0.035);
    return vec3(0.040, 0.020, 0.090);
}

vec3 viewDirToWorld(vec3 v) {
    return normalize(mat3(gbufferModelViewInverse) * v);
}

vec3 getSunDirectionWorld() { return viewDirToWorld(normalize(sunPosition)); }
vec3 getMoonDirectionWorld() { return viewDirToWorld(normalize(moonPosition)); }
vec3 getShadowLightDirectionWorld() { return viewDirToWorld(normalize(shadowLightPosition)); }

float getDayFactor() {
    return smoothstep(-0.08, 0.18, getSunDirectionWorld().y);
}

vec3 skyGradient(vec3 dir) {
    dir = normalize(dir);
    #if defined(NETHER)
        return toLinear(fogColor) * 0.82;
    #elif defined(THE_END)
        float h = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
        if (END_ATMOSPHERE == 0) {
            return mix(vec3(0.018, 0.010, 0.035), vec3(0.004, 0.002, 0.012), h);
        }
        vec3 endTint = auroraEndTint();
        vec3 endCol = mix(endTint * 1.65, vec3(0.001, 0.0015, 0.006), pow(h, 0.70));
        vec2 nebulaUV = auroraOctEncode(dir) * 3.0 + vec2(frameTimeCounter * 0.002, 0.0);
        float nebula = fbm2(nebulaUV) * fbm2(nebulaUV * 1.70 + 4.7);
        vec3 nebulaCol = mix(vec3(0.12, 0.03, 0.22), vec3(0.02, 0.18, 0.24), fbm2(nebulaUV * 0.70 - 2.0));
        nebulaCol = mix(nebulaCol, endTint * 4.0, 0.35);
        float nebulaAmount = END_ATMOSPHERE == 2 ? 1.0 : 0.45;
        endCol += nebulaCol * (nebula * END_NEBULA_STRENGTH * nebulaAmount);
        endCol += endTint * (pow(1.0 - abs(dir.y), 3.0) * 0.35);
        endCol += vec3(0.75, 0.82, 1.00) * (auroraStars(dir, STAR_AMOUNT) * 1.35 * NIGHT_SKY_BRIGHTNESS);
        return endCol;
    #else
        float day = getDayFactor();
        vec3 sunDir = getSunDirectionWorld();
        float y = max(dir.y, 0.0);
        vec3 dayCol = mix(vec3(0.52, 0.68, 0.90), vec3(0.06, 0.23, 0.72), pow(y, 0.55));
        vec3 nightCol = mix(vec3(0.015, 0.026, 0.060), vec3(0.001, 0.004, 0.020), pow(y, 0.50));
        vec3 col = mix(nightCol, dayCol, day);

        vec2 dxz = dir.xz;
        vec2 sxz = sunDir.xz;
        float dl = max(length(dxz), 0.0001);
        float sl = max(length(sxz), 0.0001);
        float az = clamp(dot(dxz / dl, sxz / sl) * 0.5 + 0.5, 0.0, 1.0);
        float twilight = 1.0 - smoothstep(0.0, 0.32, abs(sunDir.y));
        col += vec3(0.95, 0.34, 0.07) * (twilight * pow(az, 3.0) * (1.0 - pow(y, 0.5)) * 0.55);
        float nightFactor = 1.0 - day;
        float milkyBand = pow(clamp(1.0 - abs(dot(dir, normalize(vec3(0.35, 0.25, 0.90)))), 0.0, 1.0), 6.0);
        col += vec3(0.045, 0.055, 0.085) * (milkyBand * nightFactor * NIGHT_SKY_BRIGHTNESS * (1.0 - rainStrength));
        col += vec3(0.80, 0.86, 1.00) * (auroraStars(dir, STAR_AMOUNT) * nightFactor * smoothstep(0.02, 0.25, y) * (1.0 - rainStrength * 0.85) * NIGHT_SKY_BRIGHTNESS);
        col = mix(col, toLinear(fogColor), rainStrength * 0.55 * (1.0 - y));
        return col;
    #endif
}

#ifdef FRAGMENT
float getShadow(vec3 worldPos, vec3 worldNormal, float skyLight) {
    #if defined(SHADOWS) && defined(OVERWORLD)
        vec3 lightDir = getShadowLightDirectionWorld();
        float ndl = dot(worldNormal, lightDir);
        if (ndl <= 0.0 || skyLight <= 0.001) return 1.0;

        float dist = length(worldPos);
        float fade = 1.0 - smoothstep(shadowDistance * 0.72, shadowDistance, dist);
        if (fade <= 0.001) return 1.0;

        vec3 biasedPos = worldPos + worldNormal * ((0.035 + (1.0 - ndl) * 0.14) * SHADOW_BIAS_SCALE);
        vec4 sp = shadowProjection * (shadowModelView * vec4(biasedPos, 1.0));
        sp.xyz /= sp.w;
        sp.xyz = sp.xyz * 0.5 + 0.5;
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) return 1.0;

        float bias = (0.00035 + (1.0 - ndl) * 0.0016) * SHADOW_BIAS_SCALE;
        float texel = 1.0 / float(max(shadowMapResolution, 1));
        float sum = 0.0;
        float count = 0.0;
        for (int x = -SHADOW_PCF_RADIUS; x <= SHADOW_PCF_RADIUS; x++) {
            for (int y = -SHADOW_PCF_RADIUS; y <= SHADOW_PCF_RADIUS; y++) {
                float depth = texture2D(shadowtex0, sp.xy + vec2(float(x), float(y)) * texel).r;
                sum += step(sp.z - bias, depth);
                count += 1.0;
            }
        }
        return mix(1.0, sum / count, clamp(fade * SHADOW_STRENGTH, 0.0, 1.0));
    #else
        return 1.0;
    #endif
}

float cloudShadowFactor(vec3 worldPos, float skyLight) {
    #if defined(CLOUD_SHADOWS) && defined(OVERWORLD)
        vec3 sunDir = getSunDirectionWorld();
        if (sunDir.y < 0.05 || skyLight < 0.01) return 1.0;
        vec3 worldAbs = worldPos + cameraPosition;
        float cloudPlaneY = 192.0 + CLOUD_HEIGHT_OFFSET;
        float travel = (cloudPlaneY - worldAbs.y) / max(sunDir.y, 0.08);
        if (travel < 0.0) return 1.0;
        vec2 cloudUV = (worldAbs.xz + sunDir.xz * travel) * 0.006 + vec2(frameTimeCounter * 0.0025, 0.0);
        float cover = fbm2(cloudUV);
        float amount = smoothstep(0.52, 0.74, cover) * CLOUD_SHADOW_STRENGTH * skyLight * (1.0 - rainStrength * 0.35);
        return 1.0 - clamp(amount, 0.0, 0.85);
    #else
        return 1.0;
    #endif
}

vec3 lightSurface(vec3 albedo, vec3 normal, vec3 worldPos, vec2 lmcoord, float emissive) {
    vec3 N = normalize(normal);
    float blockLight = clamp(lmcoord.x, 0.0, 1.0);
    float skyLight = clamp(lmcoord.y, 0.0, 1.0);

    vec3 blockCol = vec3(1.00, 0.52, 0.22) * pow(blockLight, 2.0) * (1.35 * BLOCKLIGHT_INTENSITY);

    #if defined(NETHER)
        vec3 ambient = toLinear(fogColor) * 1.25 + vec3(0.20, 0.045, 0.025);
        vec3 direct = vec3(0.0);
    #elif defined(THE_END)
        vec3 endAmbientBase = END_ATMOSPHERE == 0 ? vec3(0.16, 0.13, 0.24) : mix(vec3(0.10, 0.08, 0.20), auroraEndTint() * 3.0, 0.45);
        vec3 ambient = endAmbientBase * (0.30 + 0.70 * skyLight) * END_LIGHT_STRENGTH;
        ambient += vec3(0.05, 0.02, 0.10) * (clamp(-N.y, 0.0, 1.0) * 0.35 * END_LIGHT_STRENGTH);
        vec3 L = normalize(vec3(0.35, 0.85, 0.25));
        float endNdl = max(dot(N, L), 0.0);
        float endWrap = clamp((dot(N, L) + 0.35) / 1.35, 0.0, 1.0);
        vec3 direct = vec3(0.55, 0.50, 0.78) * ((endNdl * 0.55 + endWrap * 0.25) * END_LIGHT_STRENGTH);
    #else
        float day = getDayFactor();
        vec3 ambient = mix(vec3(0.024, 0.035, 0.070), vec3(0.32, 0.39, 0.52), day) * (0.12 + 0.88 * pow(skyLight, 1.6));
        ambient += vec3(0.012, 0.012, 0.014);

        vec3 sunDir = getSunDirectionWorld();
        vec3 lightDir = getShadowLightDirectionWorld();
        float shadow = getShadow(worldPos, N, skyLight) * cloudShadowFactor(worldPos, skyLight);
        float ndl = max(dot(N, lightDir), 0.0);
        vec3 sunTint = mix(vec3(1.00, 0.32, 0.05), vec3(1.00, 0.84, 0.62), smoothstep(0.02, 0.50, sunDir.y));
        vec3 directCol = mix(vec3(0.35, 0.45, 0.75), sunTint, day);
        float directStrength = mix(0.22, 2.60, day) * SUN_INTENSITY * (1.0 - rainStrength * 0.70);
        vec3 direct = directCol * (ndl * shadow * pow(skyLight, 1.5) * directStrength);
    #endif

    vec3 color = albedo * (ambient + blockCol + direct);
    color += albedo * emissive;
    return color;
}

vec3 applyFog(vec3 color, vec3 worldPos, vec3 viewPos, float skyLight) {
    float dist = length(viewPos);
    float end = max(fogEnd, fogStart + 0.001);
    float factor = smoothstep(fogStart, end, dist);
    factor = pow(factor, FOG_STRENGTH);

    #if defined(OVERWORLD)
        if (isEyeInWater == 0) {
            float worldY = worldPos.y + cameraPosition.y;
            float heightFog = (1.0 - exp(-dist * 0.0038 * FOG_STRENGTH)) * exp(-max(worldY - 58.0, 0.0) * 0.03) * skyLight * 0.45;
            factor = max(factor, heightFog);
        }
    #endif

    vec3 fogTint = toLinear(fogColor);
    #if defined(THE_END)
        if (END_ATMOSPHERE > 0) {
            fogTint = auroraEndTint() * 1.35;
            factor = pow(clamp(factor, 0.0, 1.0), 1.0 / max(END_FOG_STRENGTH, 0.01));
            float voidFog = (1.0 - exp(-dist * 0.006 * END_FOG_STRENGTH)) * skyLight * 0.35;
            factor = max(factor, voidFog);
        }
    #endif

    return mix(color, fogTint, clamp(factor, 0.0, 1.0));
}
#endif
