#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec3 acesApprox(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

vec3 gradeColor(vec3 hdrColor, vec2 uv) {
    vec3 graded = max(hdrColor, vec3(0.0)) * EXPOSURE;
    graded = acesApprox(graded);
    graded = toGamma(graded);

    float lum = luminance(graded);
    graded = mix(vec3(lum), graded, SATURATION);
    graded = (graded - 0.5) * CONTRAST + 0.5;

    vec2 centeredUV = uv * 2.0 - 1.0;
    float vig = 1.0 - VIGNETTE_STRENGTH * smoothstep(0.35, 1.25, dot(centeredUV, centeredUV));
    graded *= vig;
    return graded;
}

vec3 auroraFxaaLite(vec3 center, vec3 cLeft, vec3 cRight, vec3 cDown, vec3 cUp) {
    if (AA_MODE == 0) return center;

    float lCenter = luminance(center);
    float lLeft = luminance(cLeft);
    float lRight = luminance(cRight);
    float lDown = luminance(cDown);
    float lUp = luminance(cUp);
    float lMin = min(lCenter, min(min(lLeft, lRight), min(lDown, lUp)));
    float lMax = max(lCenter, max(max(lLeft, lRight), max(lDown, lUp)));
    float contrast = lMax - lMin;
    if (contrast < 0.055) return center;

    float horizontalGradient = abs(lLeft + lRight - 2.0 * lCenter);
    float verticalGradient = abs(lDown + lUp - 2.0 * lCenter);
    vec3 alongEdge = horizontalGradient > verticalGradient ? (center * 2.0 + cDown + cUp) * 0.25 : (center * 2.0 + cLeft + cRight) * 0.25;
    float blend = (AA_MODE == 2 ? 0.65 : 0.45) * smoothstep(0.055, 0.22, contrast);
    return mix(center, alongEdge, blend);
}

void main() {
    vec3 color = gradeColor(texture2D(colortex0, texcoord).rgb, texcoord);

    if (AA_MODE > 0 || SHARPNESS > 0.001) {
        vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
        vec3 cLeft = gradeColor(texture2D(colortex0, texcoord + vec2(-texel.x, 0.0)).rgb, texcoord);
        vec3 cRight = gradeColor(texture2D(colortex0, texcoord + vec2(texel.x, 0.0)).rgb, texcoord);
        vec3 cDown = gradeColor(texture2D(colortex0, texcoord + vec2(0.0, -texel.y)).rgb, texcoord);
        vec3 cUp = gradeColor(texture2D(colortex0, texcoord + vec2(0.0, texel.y)).rgb, texcoord);

        color = auroraFxaaLite(color, cLeft, cRight, cDown, cUp);

        if (SHARPNESS > 0.001) {
            vec3 neighborAverage = (cLeft + cRight + cDown + cUp) * 0.25;
            vec3 localMin = min(color, min(min(cLeft, cRight), min(cDown, cUp)));
            vec3 localMax = max(color, max(max(cLeft, cRight), max(cDown, cUp)));
            vec3 sharpened = color + (color - neighborAverage) * (SHARPNESS * 0.85);
            color = clamp(sharpened, localMin, localMax);
        }
    }

    color += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
