# Aurora Fusion Shaders v2.2 Enhanced

An original lightweight-to-balanced shader pack for **Minecraft Java 1.21.11 + Iris**.

## New in v2 Smooth
- v2.1 fix: removed the global RGBA16F format constant that Iris rejected in composite

- Sharpness option in Post Processing
- Cloud types: Vanilla / Smooth / Puffy / Flat, plus cloud opacity, brightness, height, speed, and optional cloud shadows
- Water reflection options with sky reflection plus screen-space reflections on Balanced/Ultra
- Water wave strength, opacity, reflection strength, and shore foam controls
- Rainbow modes: Off / After Rain / Always + Double
- Shadow darkness and shadow bias controls
- Smoother distance-faded water normals to reduce sparkle/shimmer
- Performance / Balanced / Ultra profiles updated for the new options

## New in v2.2 Enhanced
- Enhanced End atmosphere: purple/blue/teal/red End fog colors, nebula sky, better End lighting and selectable star amount
- SSAO-lite ambient occlusion: Off / Fast / Quality with strength and radius controls
- FXAA Lite/Strong anti-aliasing option (real TAA needs motion history, so Aurora uses FXAA)
- Water color modes (Biome/Blue/Cyan/Green/Red/End Purple) and Water Clarity for seeing blocks under water from above
- Cloud Amount control in addition to cloud type/opacity
- Better night sky with procedural stars and a faint Milky Way band
- Lightning intensity control
- Glowing ore speckles and glowing dragon egg options
- Glass/ice reflection shine

## Features
- Sun/moon shadows with PCF softening and distance fade
- Warm daylight, blue moonlight, and block-light tinting
- Gradient sky with twilight glow, custom fog blending, and height-fog accent
- Animated water with procedural normals, fresnel sky reflection, screen-space reflection, foam, and sun glint
- Waving leaves/plants, lava/emissive boost for selected bright blocks
- ACES-style tonemapping, saturation/contrast controls, vignette, sharpness, and dithering
- Optional Iris chunk fade-in support (`FADE_VARIABLE`)

## Install
1. Install Minecraft Java 1.21.11 with Iris 1.10.8 and Sodium 0.8.14.
2. Copy this pack ZIP into `.minecraft/shaderpacks/`.
3. Select **Aurora Fusion** in Video Settings -> Shader Packs.

## Notes
The shader code in this pack was written for this project. Feature inspiration comes from common shader-pack ideas and the provided screenshots; no third-party shader code or textures are bundled.
