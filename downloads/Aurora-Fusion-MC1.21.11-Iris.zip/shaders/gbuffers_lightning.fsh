#version 120
#define FRAGMENT
#define PROGRAM_LIGHTNING
#include "/program/simple.fsh"
