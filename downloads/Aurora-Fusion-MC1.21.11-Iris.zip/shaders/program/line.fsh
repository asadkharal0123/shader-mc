#include "/lib/settings.glsl"

varying vec4 vColor;

void main() {
    vec3 color = pow(max(vColor.rgb, vec3(0.0)), vec3(2.2));
    gl_FragData[0] = vec4(color, vColor.a);
}
