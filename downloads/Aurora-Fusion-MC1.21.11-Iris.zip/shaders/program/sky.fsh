#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform int renderStage;

varying vec2 texcoord;
varying vec4 vColor;
varying vec3 vWorldDir;

void main() {
    vec3 dir = normalize(vWorldDir);

    #if defined(PROGRAM_SKYTEXTURED)
        vec4 tex = texture2D(gtexture, texcoord) * vColor;
        if (tex.a < alphaTestRef) discard;
        vec3 texColor = toLinear(tex.rgb);
        if (renderStage == MC_RENDER_STAGE_SUN) {
            texColor *= 3.0;
        } else if (renderStage == MC_RENDER_STAGE_MOON) {
            texColor *= 1.35;
        }
        if (isEyeInWater == 1) texColor *= 0.35;
        gl_FragData[0] = vec4(texColor, tex.a);
        return;
    #endif

    if (renderStage == MC_RENDER_STAGE_STARS) {
        float night = 1.0 - getDayFactor();
        gl_FragData[0] = vec4(toLinear(vColor.rgb) * (0.25 + 1.15 * night), vColor.a);
        return;
    }

    if (renderStage == MC_RENDER_STAGE_CUSTOM_SKY || renderStage == MC_RENDER_STAGE_VOID) {
        gl_FragData[0] = vec4(toLinear(vColor.rgb), vColor.a);
        return;
    }

    if (renderStage == MC_RENDER_STAGE_SUNSET) {
        gl_FragData[0] = vec4(toLinear(vColor.rgb) * 1.20, vColor.a);
        return;
    }

    vec3 color = skyGradient(dir);
    #if defined(OVERWORLD)
        float day = getDayFactor();
        float sunDot = max(dot(dir, getSunDirectionWorld()), 0.0);
        float moonDot = max(dot(dir, getMoonDirectionWorld()), 0.0);
        color += vec3(1.00, 0.55, 0.18) * (pow(sunDot, 350.0) * 2.6 + pow(sunDot, 24.0) * 0.32) * day * (1.0 - rainStrength * 0.80);
        color += vec3(0.55, 0.65, 0.90) * pow(moonDot, 600.0) * (1.0 - day) * 0.65;
        color = mix(toLinear(fogColor), color, smoothstep(-0.08, 0.18, dir.y));
    #endif

    gl_FragData[0] = vec4(color, 1.0);
}
