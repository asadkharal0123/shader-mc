#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;
varying float vChunkFade;

void main() {
    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;

    #if defined(PROGRAM_TERRAIN)
        if (vChunkFade >= 0.0 && vChunkFade < 0.999 && hash12(gl_FragCoord.xy) > vChunkFade) discard;
    #endif

    #if defined(PROGRAM_DAMAGEDBLOCK)
        gl_FragData[0] = vec4(vec3(0.0), alpha);
        return;
    #endif

    vec3 albedoSrgb = tex.rgb * vColor.rgb;
    #if defined(PROGRAM_ENTITIES) || defined(PROGRAM_ITEM)
        albedoSrgb = mix(albedoSrgb, entityColor.rgb, entityColor.a);
    #endif
    vec3 albedo = toLinear(albedoSrgb);

    vec3 N = normalize(vWorldNormal);
    if (!gl_FrontFacing) N = -N;

    #if defined(PROGRAM_WEATHER)
        vec3 weatherColor = albedo * (0.45 + 0.55 * clamp(lmcoord.y, 0.0, 1.0));
        weatherColor = applyFog(weatherColor, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(weatherColor, alpha * 0.65);
        return;
    #endif

    float emissive = int(vBlockId + 0.5) == 1010 ? 1.25 : 0.0;
    vec3 color = lightSurface(albedo, N, vWorldPos, lmcoord, emissive);
    color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);
    gl_FragData[0] = vec4(color, alpha);
}
