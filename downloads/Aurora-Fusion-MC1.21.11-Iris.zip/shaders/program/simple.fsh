#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;

void main() {
    #if defined(PROGRAM_BASIC)
        vec3 basicColor = toLinear(vColor.rgb);
        basicColor = applyFog(basicColor, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(basicColor, vColor.a);
        return;
    #endif

    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;
    vec3 color = toLinear(tex.rgb * vColor.rgb);

    #if defined(PROGRAM_BEACONBEAM)
        color *= 1.85;
    #elif defined(PROGRAM_GLINT)
        color *= vec3(0.70, 0.50, 1.30) * 1.80;
    #elif defined(PROGRAM_SPIDEREYES)
        color *= 2.00;
    #elif defined(PROGRAM_LIGHTNING)
        color = toLinear(vColor.rgb) * 4.00;
        alpha = vColor.a;
    #elif defined(PROGRAM_CLOUDS)
        float day = getDayFactor();
        color *= mix(0.32, 1.12, day);
        alpha *= 0.78;
    #else
        color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);
    #endif

    gl_FragData[0] = vec4(color, alpha);
}
