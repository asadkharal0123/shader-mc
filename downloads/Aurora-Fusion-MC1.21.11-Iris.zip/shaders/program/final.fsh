#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;

varying vec2 texcoord;

vec3 acesApprox(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    color = max(color, vec3(0.0)) * EXPOSURE;
    color = acesApprox(color);
    color = toGamma(color);

    float lum = luminance(color);
    color = mix(vec3(lum), color, SATURATION);
    color = (color - 0.5) * CONTRAST + 0.5;

    vec2 uv = texcoord * 2.0 - 1.0;
    float vig = 1.0 - VIGNETTE_STRENGTH * smoothstep(0.35, 1.25, dot(uv, uv));
    color *= vig;

    color += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
