#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vWorldAbsolute;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;

vec3 waterNormal(vec3 baseNormal) {
    vec3 N = normalize(baseNormal);
    #if WATER_DETAIL == 0
        return N;
    #elif WATER_DETAIL == 1
        vec2 p = vWorldAbsolute.xz * 0.55;
        float t = frameTimeCounter;
        vec2 grad = vec2(
            sin(p.x * 1.7 + t * 1.4) + 0.5 * sin(p.x * 3.1 - p.y * 1.3 + t * 2.0),
            cos(p.y * 1.5 - t * 1.2) + 0.5 * cos(p.y * 2.7 + p.x * 1.1 - t * 1.7)
        );
        if (abs(N.y) > 0.6) N = normalize(vec3(grad.x * 0.085, N.y, grad.y * 0.085));
        return N;
    #else
        vec2 p = vWorldAbsolute.xz * 0.45 + vec2(frameTimeCounter * 0.25, frameTimeCounter * 0.18);
        float e = 0.35;
        float hC = valueNoise2(p);
        float hX = valueNoise2(p + vec2(e, 0.0));
        float hZ = valueNoise2(p + vec2(0.0, e));
        vec2 grad = vec2(hX - hC, hZ - hC) / e;
        if (abs(N.y) > 0.6) N = normalize(vec3(grad.x * 0.14, N.y, grad.y * 0.14));
        return N;
    #endif
}

void main() {
    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;

    vec3 albedo = toLinear(tex.rgb * vColor.rgb);

    if (int(vBlockId + 0.5) == 1010) {
        float pulse = 0.92 + 0.16 * valueNoise2(vWorldAbsolute.xz * 0.35 + frameTimeCounter * 0.08);
        vec3 lava = albedo * 2.25 * pulse;
        lava = applyFog(lava, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(lava, 1.0);
        return;
    }

    vec3 N = waterNormal(vWorldNormal);
    if (!gl_FrontFacing) N = -N;
    vec3 V = normalize(-vWorldPos);
    float fresnel = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);

    vec3 diffuse = lightSurface(albedo, N, vWorldPos, lmcoord, 0.0);
    vec3 reflDir = reflect(-V, N);
    reflDir.y = abs(reflDir.y);
    vec3 reflection = skyGradient(reflDir) * 0.85;

    vec3 L = getShadowLightDirectionWorld();
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 180.0) * getShadow(vWorldPos, N, lmcoord.y) * (0.25 + 1.45 * getDayFactor()) * (1.0 - rainStrength * 0.65);

    vec3 color = mix(diffuse, reflection, clamp(fresnel, 0.0, 1.0));
    color += vec3(1.00, 0.82, 0.58) * spec;
    color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);

    float outAlpha = clamp(alpha * (0.55 + 0.45 * fresnel) + fresnel * 0.35, 0.12, 0.96);
    gl_FragData[0] = vec4(color, outAlpha);
}
