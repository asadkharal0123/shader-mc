#version 120
#define FRAGMENT
#define PROGRAM_SKYBASIC
#include "/program/sky.fsh"
