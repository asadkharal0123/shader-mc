#version 120
#define FRAGMENT
#define PROGRAM_TERRAIN
#include "/program/forward.fsh"
