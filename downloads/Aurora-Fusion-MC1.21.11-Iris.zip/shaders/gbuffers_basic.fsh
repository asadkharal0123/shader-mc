#version 120
#define FRAGMENT
#define PROGRAM_BASIC
#include "/program/simple.fsh"
