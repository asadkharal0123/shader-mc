#version 120
#define FRAGMENT
#define PROGRAM_GLINT
#include "/program/simple.fsh"
