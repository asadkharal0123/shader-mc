#version 120
#define FRAGMENT
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
