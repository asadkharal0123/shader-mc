/* Aurora Fusion settings. Options are exposed in the Iris shader menu. */

#define SHADOWS
#define WAVING_FOLIAGE

#define WATER_DETAIL 1 //[0 1 2]
#define SHADOW_PCF_RADIUS 1 //[0 1 2]

#define EXPOSURE 1.05 //[0.60 0.70 0.80 0.90 1.00 1.05 1.10 1.20 1.30 1.40 1.50]
#define SATURATION 1.06 //[0.70 0.80 0.90 1.00 1.06 1.12 1.20 1.30]
#define CONTRAST 1.03 //[0.85 0.90 0.95 1.00 1.03 1.08 1.12 1.20]
#define VIGNETTE_STRENGTH 0.28 //[0.00 0.10 0.18 0.28 0.38 0.50]
#define FOG_STRENGTH 1.00 //[0.50 0.70 0.85 1.00 1.15 1.30 1.50]
#define SUN_INTENSITY 1.00 //[0.60 0.80 1.00 1.20 1.40]
#define BLOCKLIGHT_INTENSITY 1.00 //[0.60 0.80 1.00 1.20 1.40]

const int shadowMapResolution = 2048; //[512 1024 2048 4096]
const float shadowDistance = 128.0; //[64.0 96.0 128.0 160.0 192.0 256.0]
const float shadowIntervalSize = 4.0; //[1.0 2.0 4.0 6.0 8.0]
const float entityShadowDistanceMul = 0.35; //[0.125 0.20 0.35 0.50 0.75 1.00]
const float sunPathRotation = 0.0; //[-45.0 -35.0 -25.0 -15.0 -5.0 0.0 5.0 15.0 25.0 35.0 45.0]
