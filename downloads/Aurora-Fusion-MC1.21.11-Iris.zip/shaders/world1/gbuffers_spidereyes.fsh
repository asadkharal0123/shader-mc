#version 120
#define FRAGMENT
#define THE_END
#define END
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
