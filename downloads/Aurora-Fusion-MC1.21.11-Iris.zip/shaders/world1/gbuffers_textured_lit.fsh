#version 120
#define FRAGMENT
#define THE_END
#define END
#define PROGRAM_TEXTURED_LIT
#include "/program/forward.fsh"
