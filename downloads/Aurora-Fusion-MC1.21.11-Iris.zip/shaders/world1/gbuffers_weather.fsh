#version 120
#define FRAGMENT
#define THE_END
#define END
#define PROGRAM_WEATHER
#include "/program/forward.fsh"
