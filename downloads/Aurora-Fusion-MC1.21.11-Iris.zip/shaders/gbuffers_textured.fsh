#version 120
#define FRAGMENT
#define PROGRAM_TEXTURED
#include "/program/simple.fsh"
