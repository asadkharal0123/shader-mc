#version 120
#define FRAGMENT
#define PROGRAM_DAMAGEDBLOCK
#include "/program/forward.fsh"
