#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_SKYBASIC
#include "/program/sky.fsh"
