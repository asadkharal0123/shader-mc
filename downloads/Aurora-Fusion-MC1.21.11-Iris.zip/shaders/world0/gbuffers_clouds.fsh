#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_CLOUDS
#include "/program/simple.fsh"
