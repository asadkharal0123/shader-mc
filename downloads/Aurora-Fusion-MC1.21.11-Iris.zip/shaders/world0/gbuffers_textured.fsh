#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_TEXTURED
#include "/program/simple.fsh"
