#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_SKYTEXTURED
#include "/program/sky.fsh"
