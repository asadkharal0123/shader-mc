#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_BEACONBEAM
#include "/program/simple.fsh"
