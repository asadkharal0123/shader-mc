#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_BASIC
#include "/program/simple.fsh"
