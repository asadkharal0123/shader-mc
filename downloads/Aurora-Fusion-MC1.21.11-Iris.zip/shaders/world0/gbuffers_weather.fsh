#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_WEATHER
#include "/program/forward.fsh"
