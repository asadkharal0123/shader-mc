#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_LIGHTNING
#include "/program/simple.fsh"
