#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_GLINT
#include "/program/simple.fsh"
