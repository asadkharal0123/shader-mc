#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
