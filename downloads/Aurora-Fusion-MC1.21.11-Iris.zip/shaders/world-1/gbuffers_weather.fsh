#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_WEATHER
#include "/program/forward.fsh"
