#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_SKYTEXTURED
#include "/program/sky.fsh"
