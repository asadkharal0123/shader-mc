#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_TEXTURED_LIT
#include "/program/forward.fsh"
