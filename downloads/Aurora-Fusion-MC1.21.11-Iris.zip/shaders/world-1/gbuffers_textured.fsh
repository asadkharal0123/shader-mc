#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_TEXTURED
#include "/program/simple.fsh"
