#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_GLINT
#include "/program/simple.fsh"
