#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_SKYBASIC
#include "/program/sky.fsh"
