#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_BLOCK
#include "/program/forward.fsh"
