#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_BEACONBEAM
#include "/program/simple.fsh"
