#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
