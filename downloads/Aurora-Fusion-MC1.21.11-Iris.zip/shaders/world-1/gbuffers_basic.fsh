#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_BASIC
#include "/program/simple.fsh"
