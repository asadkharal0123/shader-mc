#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_DAMAGEDBLOCK
#include "/program/forward.fsh"
