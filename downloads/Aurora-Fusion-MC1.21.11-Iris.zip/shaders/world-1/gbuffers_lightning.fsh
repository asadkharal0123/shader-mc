#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_LIGHTNING
#include "/program/simple.fsh"
