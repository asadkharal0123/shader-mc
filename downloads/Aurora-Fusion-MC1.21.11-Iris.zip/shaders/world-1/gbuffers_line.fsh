#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_LINE
#include "/program/line.fsh"
