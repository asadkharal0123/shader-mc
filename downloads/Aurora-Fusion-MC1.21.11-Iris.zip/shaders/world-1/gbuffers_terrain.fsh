#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_TERRAIN
#include "/program/forward.fsh"
