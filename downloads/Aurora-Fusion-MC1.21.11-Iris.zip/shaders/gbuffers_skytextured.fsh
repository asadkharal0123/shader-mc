#version 120
#define FRAGMENT
#define PROGRAM_SKYTEXTURED
#include "/program/sky.fsh"
