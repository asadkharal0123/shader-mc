#version 120
#define FRAGMENT
#define PROGRAM_WATER
#include "/program/water.fsh"
