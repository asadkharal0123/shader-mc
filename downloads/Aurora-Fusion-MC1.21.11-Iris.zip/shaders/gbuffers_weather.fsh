#version 120
#define FRAGMENT
#define PROGRAM_WEATHER
#include "/program/forward.fsh"
