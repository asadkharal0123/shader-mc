#version 120
#define FRAGMENT
#define PROGRAM_LINE
#include "/program/line.fsh"
