#version 120
#define FRAGMENT
#define PROGRAM_CLOUDS
#include "/program/simple.fsh"
