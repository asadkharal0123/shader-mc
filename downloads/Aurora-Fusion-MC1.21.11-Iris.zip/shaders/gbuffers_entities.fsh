#version 120
#define FRAGMENT
#define PROGRAM_ENTITIES
#include "/program/forward.fsh"
