# Aurora Fusion Shaders v2.4 Shadow + Reflection Fix

An original lightweight-to-balanced shader pack for **Minecraft Java 1.21.11 + Iris**.

## New in v2 Smooth
- v2.1 fix: removed the global RGBA16F format constant that Iris rejected in composite

- Sharpness option in Post Processing
- Cloud types: Vanilla / Smooth / Puffy / Flat, plus cloud opacity, brightness, height, speed, and optional cloud shadows
- Water reflection options with sky reflection plus screen-space reflections on Balanced/Ultra
- Water wave strength, opacity, reflection strength, and shore foam controls
- Rainbow modes: Off / After Rain / Always + Double
- Shadow darkness and shadow bias controls
- Smoother distance-faded water normals to reduce sparkle/shimmer
- Performance / Balanced / Ultra profiles updated for the new options

## New in v2.2 Enhanced
- Enhanced End atmosphere: purple/blue/teal/red End fog colors, nebula sky, better End lighting and selectable star amount
- SSAO-lite ambient occlusion: Off / Fast / Quality with strength and radius controls
- FXAA Lite/Strong anti-aliasing option (real TAA needs motion history, so Aurora uses FXAA)
- Water color modes (Biome/Blue/Cyan/Green/Red/End Purple) and Water Clarity for seeing blocks under water from above
- Cloud Amount control in addition to cloud type/opacity
- Better night sky with procedural stars and a faint Milky Way band
- Lightning intensity control
- Glowing ore speckles and glowing dragon egg options
- Glass/ice reflection shine

## New in v2.3 Fix + Effects
- Fixed cave water reflecting the sky: water sky/SSR/specular and foam are now gated by sky visibility and scene light
- Improved water SSR with more steps + binary refinement, plus procedural cloud reflections and a Water Refraction option
- Fixed oversized/glitchy stars: End uses tiny cube-face stars at low intensity; Overworld uses vanilla stars with Star Amount controlling count/brightness
- Toned down the End sky/fog (no flat saturated purple wash) and reduced nebula banding
- Night clouds no longer go pure black with orange rims; sunrise horizon/cloud colors were warmed up
- Dragon egg and ores now add independent emissive color so the purple/colored speckles actually glow
- Bamboo/sugar cane/kelp and other stalk blocks no longer wave; leaves/grass/flowers/vines keep gentle coherent waving
- Cave Darkness option, held-item Dynamic Hand Light, Bloom, camera Motion Blur, Depth of Field, and screen-space God Rays
- Real-time shadow PCF now uses distance penumbra scaling and rotated taps; profiles are Performance/Balanced = shadows off, Ultra = shadows on

## New in v2.4 Shadow + Reflection Fix
- Real-Time Shadows, Entity Shadows and Player Shadow are now separate on/off toggles, plus a Shadow Quality (Low/Medium/High) option that controls PCF filtering for all of them; Balanced profile now has shadows ON (Medium), Ultra High, Performance Off
- Glass and ice now cast shadows in the shadow pass (water still does not, so lakebeds stay lit)
- Ice reflection glitch fixed: ice is its own material (1015) - no water SSR/refraction/foam, no water color tint, near-opaque alpha, and its own Ice Reflection Strength
- Water reflection patches reduced: the top-down reflection floor was cut from 0.16 to 0.05 and removed from the SSR mask, and foam now only appears in a thin shoreline band
- Fog fixed: Fog Strength previously reduced fog when raised (pow curve) - it now scales fog distance, range 0.00-3.00, and the sky horizon follows it
- Wavy Water on/off toggle (on in Balanced/Ultra), plus Water and Underwater Red/Green/Blue multiplier sliders
- Colored light: held soul torch/lantern gives blue dynamic light, held redstone torch gives red; placed soul/redstone torches get colored flame glow

## Features
- Sun/moon shadows with PCF softening and distance fade
- Warm daylight, blue moonlight, and block-light tinting
- Gradient sky with twilight glow, custom fog blending, and height-fog accent
- Animated water with procedural normals, fresnel sky reflection, screen-space reflection, foam, and sun glint
- Waving leaves/plants, lava/emissive boost for selected bright blocks
- ACES-style tonemapping, saturation/contrast controls, vignette, sharpness, and dithering
- Optional Iris chunk fade-in support (`FADE_VARIABLE`)

## Install
1. Install Minecraft Java 1.21.11 with Iris 1.10.8 and Sodium 0.8.14.
2. Copy this pack ZIP into `.minecraft/shaderpacks/`.
3. Select **Aurora Fusion** in Video Settings -> Shader Packs.

## Notes
The shader code in this pack was written for this project. Feature inspiration comes from common shader-pack ideas and the provided screenshots; no third-party shader code or textures are bundled.
