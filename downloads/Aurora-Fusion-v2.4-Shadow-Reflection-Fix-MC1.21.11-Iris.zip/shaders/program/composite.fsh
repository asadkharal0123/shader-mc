#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec3 viewPosFromDepth(vec2 uv, float depth) {
    vec4 clipPos = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return clipPos.xyz / clipPos.w;
}

vec2 screenPosFromView(vec3 viewPos) {
    vec4 clipPos = gbufferProjection * vec4(viewPos, 1.0);
    return clipPos.xy / clipPos.w * 0.5 + 0.5;
}

vec3 depthNormal(vec2 uv, vec3 centerPos) {
    vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
    float dL = texture2D(depthtex0, uv + vec2(-texel.x, 0.0)).r;
    float dR = texture2D(depthtex0, uv + vec2(texel.x, 0.0)).r;
    float dD = texture2D(depthtex0, uv + vec2(0.0, -texel.y)).r;
    float dU = texture2D(depthtex0, uv + vec2(0.0, texel.y)).r;
    if (dL >= 0.9999 || dR >= 0.9999 || dD >= 0.9999 || dU >= 0.9999) {
        return normalize(-centerPos);
    }
    vec3 pL = viewPosFromDepth(uv + vec2(-texel.x, 0.0), dL);
    vec3 pR = viewPosFromDepth(uv + vec2(texel.x, 0.0), dR);
    vec3 pD = viewPosFromDepth(uv + vec2(0.0, -texel.y), dD);
    vec3 pU = viewPosFromDepth(uv + vec2(0.0, texel.y), dU);
    vec3 n = normalize(cross(pR - pL, pU - pD));
    if (dot(n, centerPos) > 0.0) n = -n;
    return n;
}

float auroraAmbientOcclusion(vec3 centerPos, vec3 normal) {
    #if AO_MODE == 0
        return 1.0;
    #else
        #if AO_MODE == 2
            const int aoSamples = 8;
        #else
            const int aoSamples = 4;
        #endif

        float seed = hash12(gl_FragCoord.xy);
        vec3 tangent = abs(normal.y) > 0.92 ? normalize(cross(vec3(1.0, 0.0, 0.0), normal)) : normalize(cross(vec3(0.0, 1.0, 0.0), normal));
        vec3 bitangent = cross(normal, tangent);
        float occlusion = 0.0;

        for (int i = 0; i < 8; i++) {
            if (i >= aoSamples) break;
            float fi = float(i);
            float r1 = fract(seed * 7.13 + fi * 0.61803);
            float r2 = fract(seed * 3.71 + fi * 0.75487);
            float r3 = fract(seed * 5.39 + fi * 0.38196);
            float angle = (r1 + fi / float(aoSamples)) * 6.28318530718;
            float sideScale = sqrt(max(1.0 - r2 * r2, 0.0));
            vec3 sampleDir = normalize(tangent * (cos(angle) * sideScale) + bitangent * (sin(angle) * sideScale) + normal * r2);
            vec3 samplePos = centerPos + normal * 0.03 + sampleDir * (AO_RADIUS * (0.25 + 0.75 * r3));
            if (samplePos.z > -0.05) continue;

            vec2 sampleUV = screenPosFromView(samplePos);
            if (sampleUV.x < 0.001 || sampleUV.x > 0.999 || sampleUV.y < 0.001 || sampleUV.y > 0.999) continue;

            float sampledDepth = texture2D(depthtex0, sampleUV).r;
            if (sampledDepth >= 0.9999) continue;

            vec3 scenePos = viewPosFromDepth(sampleUV, sampledDepth);
            float rangeFade = 1.0 - smoothstep(AO_RADIUS * 0.65, AO_RADIUS * 1.25, distance(centerPos, scenePos));
            if (scenePos.z > samplePos.z + 0.035) occlusion += rangeFade;
        }

        occlusion /= float(aoSamples);
        return clamp(1.0 - occlusion * AO_STRENGTH, 0.25, 1.0);
    #endif
}

vec3 screenSpaceReflection(vec3 viewPos, vec3 viewNormal, vec3 fallbackColor) {
    #if WATER_REFLECTIONS == 0
        return fallbackColor;
    #else
        vec3 reflectDir = reflect(normalize(viewPos), viewNormal);
        if (reflectDir.z > 0.20) return fallbackColor;

        #if WATER_REFLECTIONS == 2
            const int stepCount = 40;
        #else
            const int stepCount = 24;
        #endif

        vec3 rayStart = viewPos + viewNormal * 0.06;
        float previousLength = 0.05;
        float rayLength = 0.05;

        for (int i = 0; i < 40; i++) {
            if (i >= stepCount) break;
            previousLength = rayLength;
            rayLength *= 1.18;
            vec3 rayPos = rayStart + reflectDir * rayLength;
            if (rayPos.z > -0.05) break;

            vec2 hitUV = screenPosFromView(rayPos);
            if (hitUV.x < 0.001 || hitUV.x > 0.999 || hitUV.y < 0.001 || hitUV.y > 0.999) break;

            float sceneDepth = texture2D(depthtex1, hitUV).r;
            if (sceneDepth >= 0.9999) continue;

            vec3 scenePos = viewPosFromDepth(hitUV, sceneDepth);
            if (rayPos.z < scenePos.z) {
                float lowLength = previousLength;
                float highLength = rayLength;
                vec2 refinedUV = hitUV;
                for (int j = 0; j < 4; j++) {
                    float midLength = (lowLength + highLength) * 0.5;
                    vec3 midPos = rayStart + reflectDir * midLength;
                    vec2 midUV = screenPosFromView(midPos);
                    if (midUV.x < 0.001 || midUV.x > 0.999 || midUV.y < 0.001 || midUV.y > 0.999) {
                        lowLength = midLength;
                        continue;
                    }
                    float midDepth = texture2D(depthtex1, midUV).r;
                    if (midDepth >= 0.9999) {
                        lowLength = midLength;
                        continue;
                    }
                    vec3 midScenePos = viewPosFromDepth(midUV, midDepth);
                    if (midPos.z < midScenePos.z) {
                        highLength = midLength;
                        refinedUV = midUV;
                    } else {
                        lowLength = midLength;
                    }
                }
                vec2 edgeDelta = abs(refinedUV - 0.5) * 2.0;
                float edgeFade = 1.0 - smoothstep(0.78, 1.0, max(edgeDelta.x, edgeDelta.y));
                float distanceFade = 1.0 - smoothstep(24.0, 64.0, rayLength);
                return mix(fallbackColor, texture2D(colortex0, refinedUV).rgb, edgeFade * distanceFade);
            }
        }

        return fallbackColor;
    #endif
}

vec3 auroraGodRays(vec3 color) {
    #if defined(OVERWORLD)
        if (GOD_RAYS_STRENGTH < 0.001) return color;
        vec3 lightDirView = normalize(shadowLightPosition);
        if (lightDirView.z > -0.08) return color;
        vec4 lightClip = gbufferProjection * vec4(lightDirView * 100.0, 1.0);
        if (lightClip.w <= 0.0) return color;
        vec2 sunUV = lightClip.xy / lightClip.w * 0.5 + 0.5;
        vec2 rayStep = (sunUV - texcoord) / 12.0;
        vec2 sampleUV = texcoord;
        vec3 rays = vec3(0.0);
        float decay = 1.0;
        for (int i = 0; i < 12; i++) {
            sampleUV += rayStep;
            if (sampleUV.x < 0.001 || sampleUV.x > 0.999 || sampleUV.y < 0.001 || sampleUV.y > 0.999) break;
            if (texture2D(depthtex0, sampleUV).r >= 0.9999) {
                rays += max(texture2D(colortex0, sampleUV).rgb - vec3(0.55), vec3(0.0)) * decay;
            }
            decay *= 0.86;
        }
        vec3 sunDirWorld = getSunDirectionWorld();
        float twilightBoost = 1.0 - smoothstep(0.0, 0.32, abs(sunDirWorld.y));
        float rayAmount = clamp(getDayFactor() + twilightBoost * 0.60, 0.0, 1.0) * (1.0 - rainStrength * 0.65);
        return color + rays * ((GOD_RAYS_STRENGTH / 12.0) * rayAmount);
    #else
        return color;
    #endif
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    vec4 waterData = texture2D(colortex1, texcoord);

    #if AO_MODE > 0
        float centerDepth = texture2D(depthtex0, texcoord).r;
        if (centerDepth < 0.9999) {
            vec3 centerViewPos = viewPosFromDepth(texcoord, centerDepth);
            if (length(centerViewPos) > 1.25) {
                float ao = auroraAmbientOcclusion(centerViewPos, depthNormal(texcoord, centerViewPos));
                float aoWeight = waterData.a > 0.003 ? 0.35 : 1.0;
                color *= mix(1.0, ao, aoWeight);
            }
        }
    #endif

    if (waterData.a > 0.003) {
        float surfaceDepth = texture2D(depthtex0, texcoord).r;
        if (surfaceDepth < 0.9999) {
            vec3 surfaceViewPos = viewPosFromDepth(texcoord, surfaceDepth);
            vec3 surfaceViewNormal = normalize(waterData.rgb * 2.0 - 1.0);

            if (WATER_REFRACTION_STRENGTH > 0.001) {
                vec2 refractUV = clamp(texcoord + surfaceViewNormal.xy * (0.010 * WATER_REFRACTION_STRENGTH), vec2(0.001), vec2(0.999));
                color = mix(color, texture2D(colortex0, refractUV).rgb, 0.28 * clamp(WATER_REFRACTION_STRENGTH, 0.0, 1.0));
            }

            #if WATER_REFLECTIONS > 0
                if (waterData.a > 0.021) {
                    vec3 reflectionColor = screenSpaceReflection(surfaceViewPos, surfaceViewNormal, color);
                    color = mix(color, reflectionColor, clamp(waterData.a * 0.90, 0.0, 1.0));
                }
            #endif

            float opaqueDepth = texture2D(depthtex1, texcoord).r;
            if (opaqueDepth < 0.9999 && WATER_FOAM_STRENGTH > 0.001) {
                vec3 opaqueViewPos = viewPosFromDepth(texcoord, opaqueDepth);
                float waterThickness = distance(surfaceViewPos, opaqueViewPos);
                float foamBand = 1.0 - smoothstep(0.02, 0.28, waterThickness);
                vec3 surfaceWorldPos = (gbufferModelViewInverse * vec4(surfaceViewPos, 1.0)).xyz + cameraPosition;
                float foamNoise = valueNoise2(surfaceWorldPos.xz * 2.30 + vec2(frameTimeCounter * 0.35, -frameTimeCounter * 0.22));
                float foam = foamBand * smoothstep(0.55, 0.90, foamNoise) * WATER_FOAM_STRENGTH;
                float foamLight = clamp(luminance(color) * 2.50, 0.05, 1.0);
                vec3 foamColor = vec3(0.85, 0.92, 1.00) * ((0.35 + 0.65 * getDayFactor()) * foamLight);
                color = mix(color, foamColor, clamp(foam, 0.0, 1.0));
            }
        }
    }

    color = auroraGodRays(color);

    gl_FragData[0] = vec4(color, 1.0);
}
