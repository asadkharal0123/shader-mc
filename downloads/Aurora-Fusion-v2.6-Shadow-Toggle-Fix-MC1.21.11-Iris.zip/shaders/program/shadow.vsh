#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/waving.glsl"

varying vec2 texcoord;
varying vec4 vColor;
varying float vBlockId;

void main() {
    vec3 pos = applyWaving(gl_Vertex.xyz);
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    vBlockId = mc_Entity.x;
    gl_Position = gl_ProjectionMatrix * (gl_ModelViewMatrix * vec4(pos, 1.0));
}
