#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec3 acesApprox(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

vec3 gradeColor(vec3 hdrColor, vec2 uv) {
    vec3 graded = max(hdrColor, vec3(0.0)) * EXPOSURE;
    graded = acesApprox(graded);
    graded = toGamma(graded);

    float lum = luminance(graded);
    graded = mix(vec3(lum), graded, SATURATION);
    graded = (graded - 0.5) * CONTRAST + 0.5;

    vec2 centeredUV = uv * 2.0 - 1.0;
    float vig = 1.0 - VIGNETTE_STRENGTH * smoothstep(0.35, 1.25, dot(centeredUV, centeredUV));
    graded *= vig;
    return graded;
}

vec3 hdrAt(vec2 uv) {
    return texture2D(colortex0, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
}

vec3 viewPosFromDepthFinal(vec2 uv, float depth) {
    vec4 clipPos = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return clipPos.xyz / clipPos.w;
}

vec3 auroraFxaaLite(vec3 center, vec3 cLeft, vec3 cRight, vec3 cDown, vec3 cUp) {
    if (AA_MODE == 0) return center;

    float lCenter = luminance(center);
    float lLeft = luminance(cLeft);
    float lRight = luminance(cRight);
    float lDown = luminance(cDown);
    float lUp = luminance(cUp);
    float lMin = min(lCenter, min(min(lLeft, lRight), min(lDown, lUp)));
    float lMax = max(lCenter, max(max(lLeft, lRight), max(lDown, lUp)));
    float contrast = lMax - lMin;
    if (contrast < 0.055) return center;

    float horizontalGradient = abs(lLeft + lRight - 2.0 * lCenter);
    float verticalGradient = abs(lDown + lUp - 2.0 * lCenter);
    vec3 alongEdge = horizontalGradient > verticalGradient ? (center * 2.0 + cDown + cUp) * 0.25 : (center * 2.0 + cLeft + cRight) * 0.25;
    float blend = (AA_MODE == 2 ? 0.65 : 0.45) * smoothstep(0.055, 0.22, contrast);
    return mix(center, alongEdge, blend);
}

void main() {
    vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
    vec3 centerHDR = hdrAt(texcoord);

    float centerDepth = texture2D(depthtex0, texcoord).r;
    vec3 centerViewPos = viewPosFromDepthFinal(texcoord, centerDepth);
    float centerDistance = centerDepth >= 0.9999 ? 512.0 : length(centerViewPos);

    if (MOTION_BLUR_STRENGTH > 0.001 && centerDepth < 0.9999) {
        vec3 worldRelative = (gbufferModelViewInverse * vec4(centerViewPos, 1.0)).xyz;
        vec4 previousView = gbufferPreviousModelView * vec4(worldRelative + cameraPosition - previousCameraPosition, 1.0);
        if (previousView.z < -0.05) {
            vec4 previousClip = gbufferPreviousProjection * previousView;
            vec2 previousUV = previousClip.xy / previousClip.w * 0.5 + 0.5;
            vec2 velocity = clamp(texcoord - previousUV, vec2(-0.040), vec2(0.040)) * MOTION_BLUR_STRENGTH;
            vec3 motionSum = centerHDR;
            motionSum += hdrAt(texcoord - velocity * 0.20);
            motionSum += hdrAt(texcoord - velocity * 0.40);
            motionSum += hdrAt(texcoord - velocity * 0.60);
            motionSum += hdrAt(texcoord - velocity * 0.80);
            motionSum += hdrAt(texcoord - velocity);
            centerHDR = motionSum / 6.0;
        }
    }

    if (DOF_STRENGTH > 0.001) {
        float focusDepth = texture2D(depthtex0, vec2(0.5)).r;
        float focusDistance = focusDepth >= 0.9999 ? 32.0 : length(viewPosFromDepthFinal(vec2(0.5), focusDepth));
        float coc = clamp(abs(centerDistance - focusDistance) / max(focusDistance, 1.0), 0.0, 1.0) * DOF_STRENGTH;
        if (coc > 0.01) {
            vec2 blurRadius = texel * (1.0 + coc * 6.0);
            vec3 dofSum = centerHDR;
            dofSum += hdrAt(texcoord + vec2(-blurRadius.x, 0.0));
            dofSum += hdrAt(texcoord + vec2(blurRadius.x, 0.0));
            dofSum += hdrAt(texcoord + vec2(0.0, -blurRadius.y));
            dofSum += hdrAt(texcoord + vec2(0.0, blurRadius.y));
            dofSum += hdrAt(texcoord + vec2(-blurRadius.x, -blurRadius.y));
            dofSum += hdrAt(texcoord + vec2(blurRadius.x, -blurRadius.y));
            dofSum += hdrAt(texcoord + vec2(-blurRadius.x, blurRadius.y));
            dofSum += hdrAt(texcoord + vec2(blurRadius.x, blurRadius.y));
            centerHDR = mix(centerHDR, dofSum / 9.0, coc);
        }
    }

    if (BLOOM_STRENGTH > 0.001) {
        vec3 bright = vec3(0.0);
        bright += max(hdrAt(texcoord + texel * vec2(-3.0, 0.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(3.0, 0.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(0.0, -3.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(0.0, 3.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(-6.0, -6.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(6.0, -6.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(-6.0, 6.0)) - vec3(0.80), vec3(0.0));
        bright += max(hdrAt(texcoord + texel * vec2(6.0, 6.0)) - vec3(0.80), vec3(0.0));
        centerHDR += bright * (BLOOM_STRENGTH * 0.18);
    }

    vec3 color = gradeColor(centerHDR, texcoord);

    if (AA_MODE > 0 || SHARPNESS > 0.001) {
        vec3 cLeft = gradeColor(hdrAt(texcoord + vec2(-texel.x, 0.0)), texcoord);
        vec3 cRight = gradeColor(hdrAt(texcoord + vec2(texel.x, 0.0)), texcoord);
        vec3 cDown = gradeColor(hdrAt(texcoord + vec2(0.0, -texel.y)), texcoord);
        vec3 cUp = gradeColor(hdrAt(texcoord + vec2(0.0, texel.y)), texcoord);

        color = auroraFxaaLite(color, cLeft, cRight, cDown, cUp);

        if (SHARPNESS > 0.001) {
            vec3 neighborAverage = (cLeft + cRight + cDown + cUp) * 0.25;
            vec3 localMin = min(color, min(min(cLeft, cRight), min(cDown, cUp)));
            vec3 localMax = max(color, max(max(cLeft, cRight), max(cDown, cUp)));
            vec3 sharpened = color + (color - neighborAverage) * (SHARPNESS * 0.85);
            color = clamp(sharpened, localMin, localMax);
        }
    }

    color += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
