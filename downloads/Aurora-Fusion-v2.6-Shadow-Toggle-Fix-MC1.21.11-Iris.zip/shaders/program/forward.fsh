#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;
varying float vChunkFade;

float oreGlowMask(vec3 srgb) {
    float maxc = max(max(srgb.r, srgb.g), srgb.b);
    float minc = min(min(srgb.r, srgb.g), srgb.b);
    float sat = maxc - minc;
    float colored = smoothstep(0.08, 0.30, sat);
    float redstone = smoothstep(0.25, 0.55, srgb.r - max(srgb.g, srgb.b));
    float paleSpeckle = smoothstep(0.45, 0.85, maxc) * smoothstep(0.03, 0.16, sat);
    return clamp(max(colored, redstone) * smoothstep(0.12, 0.35, maxc) + paleSpeckle * 0.35, 0.0, 1.0);
}

float dragonEggGlowMask(vec3 srgb) {
    float purple = smoothstep(0.05, 0.28, ((srgb.r + srgb.b) * 0.5) - srgb.g);
    float spots = smoothstep(0.12, 0.45, max(srgb.r, srgb.b));
    return clamp(purple * spots + 0.12, 0.0, 1.0);
}

void main() {
    gl_FragData[1] = vec4(0.0);
    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;

    #if defined(PROGRAM_TERRAIN)
        if (vChunkFade >= 0.0 && vChunkFade < 0.999 && hash12(gl_FragCoord.xy) > vChunkFade) discard;
    #endif

    #if defined(PROGRAM_DAMAGEDBLOCK)
        gl_FragData[0] = vec4(vec3(0.0), alpha);
        return;
    #endif

    vec3 albedoSrgb = tex.rgb * vColor.rgb;
    #if defined(PROGRAM_ENTITIES) || defined(PROGRAM_ITEM)
        albedoSrgb = mix(albedoSrgb, entityColor.rgb, entityColor.a);
    #endif
    vec3 albedo = toLinear(albedoSrgb);

    vec3 N = normalize(vWorldNormal);
    if (!gl_FrontFacing) N = -N;

    #if defined(PROGRAM_WEATHER)
        vec3 weatherColor = albedo * (0.45 + 0.55 * clamp(lmcoord.y, 0.0, 1.0));
        weatherColor = applyFog(weatherColor, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(weatherColor, alpha * 0.65);
        return;
    #endif

    int blockId = int(vBlockId + 0.5);
    float emissive = blockId == 1010 ? 1.25 : 0.0;
    vec3 color = lightSurface(albedo, N, vWorldPos, lmcoord, emissive);

    #if GLOWING_ORES == 1
        if (blockId == 1012) {
            color += toLinear(albedoSrgb) * (oreGlowMask(albedoSrgb) * ORE_GLOW_STRENGTH * 2.40);
        }
    #endif
    #if GLOWING_DRAGON_EGG == 1
        if (blockId == 1013) {
            float eggMask = dragonEggGlowMask(albedoSrgb);
            color += vec3(0.38, 0.05, 0.85) * (eggMask * DRAGON_EGG_GLOW_STRENGTH * 1.80);
            color += toLinear(albedoSrgb) * (eggMask * DRAGON_EGG_GLOW_STRENGTH * 0.80);
        }
    #endif

    if (blockId == 1016) {
        float soulMask = smoothstep(0.20, 0.75, luminance(albedoSrgb));
        color += vec3(0.20, 0.55, 1.05) * (soulMask * 1.10 + 0.10);
    } else if (blockId == 1017) {
        float redMask = smoothstep(0.20, 0.75, luminance(albedoSrgb));
        color += vec3(1.05, 0.16, 0.08) * (redMask * 0.95 + 0.08);
    }

    #if GLASS_REFLECTIONS == 1
        if (blockId == 1011 || blockId == 1014 || blockId == 1015) {
            vec3 viewDirWorld = normalize(-vWorldPos);
            float glassFresnel = 0.04 + 0.96 * pow(1.0 - max(dot(N, viewDirWorld), 0.0), 5.0);
            vec3 glassReflection = skyGradient(reflect(-viewDirWorld, N));
            vec3 glassLightDir = getShadowLightDirectionWorld();
            #if defined(THE_END)
                glassLightDir = normalize(vec3(0.35, 0.85, 0.25));
            #endif
            float specPower = blockId == 1011 ? 90.0 : (blockId == 1015 ? 70.0 : 55.0);
            float reflectionStrength = blockId == 1011 ? GLASS_REFLECTION_STRENGTH : (blockId == 1015 ? ICE_REFLECTION_STRENGTH : POLISHED_REFLECTION_STRENGTH);
            float glassSkyVis = pow(clamp(lmcoord.y, 0.0, 1.0), 1.25);
            #if defined(THE_END)
                glassSkyVis = max(glassSkyVis, 0.65);
            #endif
            float glassSpec = pow(max(dot(N, normalize(glassLightDir + viewDirWorld)), 0.0), specPower) * glassSkyVis;
            float glassLightAmount = clamp(lmcoord.y + 0.15, 0.0, 1.0);
            color += (glassReflection * (glassFresnel * glassSkyVis) + vec3(1.00, 0.90, 0.75) * (glassSpec * 0.45)) * (reflectionStrength * glassLightAmount);
        }
    #endif

    color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);
    gl_FragData[0] = vec4(color, alpha);
}
