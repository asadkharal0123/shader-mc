#include "/lib/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec4 vColor;
varying float vBlockId;

void main() {
    float alpha = texture2D(gtexture, texcoord).a * vColor.a;
    #if defined(PROGRAM_SHADOW_WATER)
        int bid = int(vBlockId + 0.5);
        if (bid != 1011 && bid != 1015) discard;
        if (alpha < 0.10) discard;
    #else
        if (alpha < alphaTestRef) discard;
    #endif
    gl_FragData[0] = vec4(1.0);
}
