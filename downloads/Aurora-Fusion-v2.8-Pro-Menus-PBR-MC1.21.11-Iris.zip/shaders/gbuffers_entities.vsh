#version 120
#define VERTEX
#define PROGRAM_ENTITIES
#include "/program/forward.vsh"
