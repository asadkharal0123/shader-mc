#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
