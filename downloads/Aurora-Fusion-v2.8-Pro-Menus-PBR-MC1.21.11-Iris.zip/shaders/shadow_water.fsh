#version 120
#define FRAGMENT
#define PROGRAM_SHADOW_WATER
#include "/program/shadow.fsh"
