#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_BLOCK
#include "/program/forward.fsh"
