#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_BEACONBEAM
#include "/program/simple.fsh"
