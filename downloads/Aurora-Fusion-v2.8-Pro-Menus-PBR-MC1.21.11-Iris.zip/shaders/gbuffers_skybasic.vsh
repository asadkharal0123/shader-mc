#version 120
#define VERTEX
#define PROGRAM_SKYBASIC
#include "/program/sky.vsh"
