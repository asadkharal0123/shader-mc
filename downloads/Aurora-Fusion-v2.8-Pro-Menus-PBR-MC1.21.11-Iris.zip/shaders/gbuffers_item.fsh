#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_ITEM
#include "/program/forward.fsh"
