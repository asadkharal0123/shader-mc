#version 120
#define VERTEX
#define PROGRAM_ITEM
#include "/program/forward.vsh"
