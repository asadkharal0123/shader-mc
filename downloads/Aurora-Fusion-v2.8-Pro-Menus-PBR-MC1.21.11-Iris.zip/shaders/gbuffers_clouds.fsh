#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_CLOUDS
#include "/program/simple.fsh"
