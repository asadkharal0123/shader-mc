#version 120
#define VERTEX
#define PROGRAM_SPIDEREYES
#include "/program/simple.vsh"
