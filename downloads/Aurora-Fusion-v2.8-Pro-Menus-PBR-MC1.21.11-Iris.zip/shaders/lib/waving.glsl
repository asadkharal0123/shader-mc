/* Foliage motion. Included only by terrain/shadow vertex programs. */
#ifdef VERTEX
attribute vec4 mc_Entity;
attribute vec3 at_midBlock;
attribute vec2 mc_midTexCoord;

vec3 applyWaving(vec3 pos) {
    #if WAVING_FOLIAGE == 1 && (defined(PROGRAM_TERRAIN) || defined(PROGRAM_SHADOW))
        int blockId = int(mc_Entity.x + 0.5);
        bool isLeaves = blockId == 1001;
        bool isPlants = blockId == 1002 || blockId == 1003;
        bool isLily = blockId == 1004;

        if ((isLeaves && WAVING_LEAVES == 1) || (isPlants && WAVING_GRASS == 1) || (isLily && WAVING_LILY == 1)) {
            vec3 worldAbs = pos + cameraPosition;
            vec3 blockCenter = worldAbs - at_midBlock * 0.015625;
            float t = frameTimeCounter * WAVING_SPEED;
            float amp = WAVING_INTENSITY;
            amp *= mix(1.0, WAVING_RAIN_MULTIPLIER, rainStrength);
            if (WAVING_CLOSED_AREAS == 1) {
                float skyAccess = (gl_TextureMatrix[1] * gl_MultiTexCoord1).y;
                amp *= smoothstep(0.05, 0.55, skyAccess);
            }

            if (isLeaves) {
                float phase = blockCenter.x * 0.55 + blockCenter.z * 0.45 + blockCenter.y * 0.18;
                pos.x += sin(t * 1.15 + phase) * 0.018 * amp;
                pos.z += cos(t * 0.95 + phase * 1.31) * 0.018 * amp;
            } else if (isPlants) {
                float heightWeight = clamp(at_midBlock.y * 0.015625 + 0.5, 0.0, 1.0);
                float phase = blockCenter.x * 0.85 + blockCenter.z * 0.70;
                float sway = (sin(t * 1.7 + phase) + 0.45 * sin(t * 2.9 + phase * 1.7)) * 0.050 * heightWeight * amp;
                pos.x += sway;
                pos.z += sway * 0.62;
            } else {
                float phase = blockCenter.x * 0.80 + blockCenter.z * 0.70;
                pos.y += sin(t * 1.4 + phase) * 0.030 * amp;
                pos.x += sin(t * 1.1 + phase * 1.3) * 0.010 * amp;
            }
        }
    #endif
    return pos;
}
#endif
