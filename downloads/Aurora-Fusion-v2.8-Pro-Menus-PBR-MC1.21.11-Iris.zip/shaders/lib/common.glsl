/* Shared helpers and uniforms for Aurora Fusion. */

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform float fogStart;
uniform float fogEnd;
uniform float fogDensity;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float wetness;
uniform int isEyeInWater;
uniform int worldTime;
uniform int moonPhase;
uniform float alphaTestRef;
uniform vec4 entityColor;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

#ifdef FRAGMENT
uniform sampler2D gtexture;
uniform sampler2D shadowtex0;
#endif

float saturate1(float x) { return clamp(x, 0.0, 1.0); }
vec3 saturate3(vec3 x) { return clamp(x, vec3(0.0), vec3(1.0)); }
float luminance(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 toLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 toGamma(vec3 c) { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float valueNoise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x),
        mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x),
        u.y
    );
}

float fbm2(vec2 p) {
    float v = 0.0;
    float a = 0.55;
    for (int i = 0; i < 3; i++) {
        v += valueNoise2(p) * a;
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return v;
}

float auroraStars(vec3 dir, float amount) {
    if (amount < 0.01) return 0.0;
    float amt = clamp(amount, 0.0, 2.0);
    vec3 d = normalize(dir);
    vec3 ad = abs(d);
    vec2 uv;
    float face = 0.0;
    if (ad.x >= ad.y && ad.x >= ad.z) {
        uv = d.zy / d.x;
        face = d.x > 0.0 ? 0.0 : 1.0;
    } else if (ad.y >= ad.z) {
        uv = d.xz / d.y;
        face = d.y > 0.0 ? 2.0 : 3.0;
    } else {
        uv = d.xy / d.z;
        face = d.z > 0.0 ? 4.0 : 5.0;
    }
    uv = uv * 0.5 + 0.5;
    float grid = 130.0 + amt * 70.0;
    vec2 cell = floor(uv * grid) + face * 37.0;
    vec2 local = fract(uv * grid);
    float h1 = hash12(cell * 1.71 + vec2(13.7, 57.3));
    float h2 = hash12(cell * 2.33 + vec2(91.7, 17.9));
    float h3 = hash12(cell * 0.91 + vec2(41.0, 3.0));
    vec2 center = vec2(0.30 + 0.40 * h1, 0.30 + 0.40 * h2);
    float point = smoothstep(0.075, 0.015, distance(local, center));
    float threshold = 1.0 - 0.010 * amt - 0.006 * amt * amt;
    float twinkle = 0.85 + 0.15 * sin(frameTimeCounter * (1.0 + h1 * 3.0) + h1 * 91.0);
    return point * step(threshold, h3) * twinkle;
}

vec3 auroraEndTint() {
    if (END_FOG_COLOR == 1) return vec3(0.004, 0.012, 0.040);
    if (END_FOG_COLOR == 2) return vec3(0.003, 0.032, 0.026);
    if (END_FOG_COLOR == 3) return vec3(0.038, 0.006, 0.010);
    return vec3(0.012, 0.006, 0.030);
}

vec3 viewDirToWorld(vec3 v) {
    return normalize(mat3(gbufferModelViewInverse) * v);
}

vec3 getSunDirectionWorld() { return viewDirToWorld(normalize(sunPosition)); }
vec3 getMoonDirectionWorld() { return viewDirToWorld(normalize(moonPosition)); }
vec3 getShadowLightDirectionWorld() { return viewDirToWorld(normalize(shadowLightPosition)); }

float getDayFactor() {
    return smoothstep(-0.08, 0.18, getSunDirectionWorld().y);
}

vec3 auroraTimeMultiplier(vec3 sunriseColor, vec3 noonColor, vec3 nightColor, vec3 rainColor) {
    float day = getDayFactor();
    vec3 sunDir = getSunDirectionWorld();
    float twilight = (1.0 - smoothstep(0.02, 0.34, abs(sunDir.y))) * smoothstep(-0.24, -0.04, sunDir.y);
    vec3 result = mix(nightColor, noonColor, day);
    result = mix(result, sunriseColor, clamp(twilight, 0.0, 1.0));
    return mix(result, rainColor, clamp(rainStrength, 0.0, 1.0) * 0.85);
}

vec3 lightingColorMultiplier() {
    if (LIGHT_COLOR_MULTIPLIERS == 0) return vec3(1.0);
    #if defined(NETHER)
        return vec3(LCM_NETHER_RED, LCM_NETHER_GREEN, LCM_NETHER_BLUE);
    #elif defined(THE_END)
        return vec3(LCM_END_RED, LCM_END_GREEN, LCM_END_BLUE);
    #else
        return auroraTimeMultiplier(
            vec3(LCM_SUNRISE_RED, LCM_SUNRISE_GREEN, LCM_SUNRISE_BLUE),
            vec3(LCM_NOON_RED, LCM_NOON_GREEN, LCM_NOON_BLUE),
            vec3(LCM_NIGHT_RED, LCM_NIGHT_GREEN, LCM_NIGHT_BLUE),
            vec3(LCM_RAIN_RED, LCM_RAIN_GREEN, LCM_RAIN_BLUE)
        );
    #endif
}

vec3 atmosphereColorMultiplier() {
    if (ATMO_COLOR_MULTIPLIERS == 0) return vec3(1.0);
    #if defined(NETHER)
        return vec3(ACM_NETHER_RED, ACM_NETHER_GREEN, ACM_NETHER_BLUE);
    #elif defined(THE_END)
        return vec3(ACM_END_RED, ACM_END_GREEN, ACM_END_BLUE);
    #else
        return auroraTimeMultiplier(
            vec3(ACM_SUNRISE_RED, ACM_SUNRISE_GREEN, ACM_SUNRISE_BLUE),
            vec3(ACM_NOON_RED, ACM_NOON_GREEN, ACM_NOON_BLUE),
            vec3(ACM_NIGHT_RED, ACM_NIGHT_GREEN, ACM_NIGHT_BLUE),
            vec3(ACM_RAIN_RED, ACM_RAIN_GREEN, ACM_RAIN_BLUE)
        );
    #endif
}

vec3 skyGradient(vec3 dir) {
    dir = normalize(dir);
    #if defined(NETHER)
        return toLinear(fogColor) * 0.82 * atmosphereColorMultiplier();
    #elif defined(THE_END)
        float h = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
        if (END_ATMOSPHERE == 0) {
            return mix(vec3(0.018, 0.010, 0.035), vec3(0.004, 0.002, 0.012), h);
        }
        vec3 endTint = auroraEndTint();
        vec3 endCol = mix(endTint * 0.75, vec3(0.0004, 0.0005, 0.0020), pow(h, 0.65));
        vec2 nebulaUV = vec2(dir.x + dir.y * 0.60, dir.z - dir.y * 0.40) * 2.20 + vec2(frameTimeCounter * 0.002, 0.0);
        float nebula = fbm2(nebulaUV) * fbm2(nebulaUV * 1.70 + 4.7);
        vec3 nebulaCol = mix(vec3(0.16, 0.04, 0.30), vec3(0.05, 0.10, 0.28), fbm2(nebulaUV * 0.70 - 2.0));
        nebulaCol = mix(nebulaCol, endTint * 3.0, 0.30);
        float nebulaAmount = END_ATMOSPHERE == 2 ? 1.10 : 0.40;
        endCol += nebulaCol * (nebula * END_NEBULA_STRENGTH * nebulaAmount);
        endCol += endTint * (pow(1.0 - abs(dir.y), 3.0) * 0.12);
        endCol += vec3(0.75, 0.82, 1.00) * (auroraStars(dir, STAR_AMOUNT) * (END_ATMOSPHERE == 2 ? 1.00 : 0.65) * NIGHT_SKY_BRIGHTNESS);
        return endCol * atmosphereColorMultiplier();
    #else
        float day = getDayFactor();
        vec3 sunDir = getSunDirectionWorld();
        float y = max(dir.y, 0.0);
        vec3 dayCol = mix(vec3(0.52, 0.68, 0.90), vec3(0.06, 0.23, 0.72), pow(y, 0.55));
        vec3 nightCol = mix(vec3(0.015, 0.026, 0.060), vec3(0.001, 0.004, 0.020), pow(y, 0.50));
        vec3 col = mix(nightCol, dayCol, day);

        vec2 dxz = dir.xz;
        vec2 sxz = sunDir.xz;
        float dl = max(length(dxz), 0.0001);
        float sl = max(length(sxz), 0.0001);
        float az = clamp(dot(dxz / dl, sxz / sl) * 0.5 + 0.5, 0.0, 1.0);
        float twilight = 1.0 - smoothstep(0.0, 0.32, abs(sunDir.y));
        col += vec3(0.95, 0.34, 0.07) * (twilight * pow(az, 3.0) * (1.0 - pow(y, 0.5)) * 0.55 * SUNSET_GLOW_STRENGTH);
        float sunrise = smoothstep(-0.08, 0.12, sunDir.y) * (1.0 - smoothstep(0.18, 0.48, sunDir.y));
        vec3 sunriseHorizon = mix(vec3(0.30, 0.12, 0.28), vec3(1.00, 0.40, 0.10), pow(az, 2.0));
        col = mix(col, sunriseHorizon, clamp(sunrise * (1.0 - pow(y, 0.45)) * 0.55 * SUNSET_GLOW_STRENGTH, 0.0, 1.0));
        col += vec3(1.00, 0.34, 0.07) * (twilight * pow(az, 5.0) * (1.0 - y) * 0.45 * SUNSET_GLOW_STRENGTH);
        float nightAmount = (1.0 - day) * smoothstep(0.02, 0.24, dir.y);
        if (NIGHT_NEBULAE == 1 && nightAmount > 0.001) {
            vec2 nightNebulaUV = vec2(dir.x + dir.y * 0.55, dir.z - dir.y * 0.35) * 2.10 + vec2(frameTimeCounter * 0.0015, 0.0);
            float nightNebula = fbm2(nightNebulaUV) * fbm2(nightNebulaUV * 1.65 + 3.7);
            vec3 nightNebulaCol = mix(vec3(0.10, 0.03, 0.22), vec3(0.01, 0.10, 0.20), fbm2(nightNebulaUV * 0.70 - 1.5));
            col += nightNebulaCol * (nightNebula * nightAmount * (1.0 - rainStrength) * NIGHT_NEBULA_BRIGHTNESS * 0.16);
        }
        if (AURORA_BOREALIS_STYLE > 0 && nightAmount > 0.001) {
            float auroraGate = nightAmount;
            if (AURORA_CONDITION == 0) auroraGate *= 1.0 - rainStrength;
            else if (AURORA_CONDITION == 1) auroraGate *= (moonPhase == 0 ? 1.0 : 0.0) * (1.0 - rainStrength * 0.65);
            float auroraWave = fbm2(vec2(dir.x * 1.7 + dir.z * 1.3, dir.z * 1.1 - dir.x * 0.8) + vec2(frameTimeCounter * 0.008, 0.0));
            float auroraBandY = 0.36 + (auroraWave - 0.5) * 0.22;
            float auroraBand = exp(-pow((dir.y - auroraBandY) * 5.2, 2.0));
            float auroraRays = 0.55 + 0.45 * sin((dir.x * 18.0 + dir.z * 13.0) + auroraWave * 9.0 - frameTimeCounter * 0.22);
            float auroraStyleScale = AURORA_BOREALIS_STYLE == 1 ? 0.38 : (AURORA_BOREALIS_STYLE == 2 ? 0.75 : 1.15);
            vec3 auroraCol = mix(vec3(0.05, 0.95, 0.35), vec3(0.45, 0.12, 0.95), clamp(auroraWave * 1.20 - 0.10, 0.0, 1.0));
            col += auroraCol * (auroraBand * auroraRays * auroraGate * AURORA_BRIGHTNESS * auroraStyleScale * 0.24);
        }
        col = mix(col, toLinear(fogColor), rainStrength * 0.55 * (1.0 - y));
        return col * atmosphereColorMultiplier();
    #endif
}

#ifdef FRAGMENT
float getShadow(vec3 worldPos, vec3 worldNormal, float skyLight) {
    #if SHADOWS == 1 && defined(OVERWORLD)
        vec3 lightDir = getShadowLightDirectionWorld();
        float ndl = dot(worldNormal, lightDir);
        if (ndl <= 0.0 || skyLight <= 0.001) return 1.0;

        float dist = length(worldPos);
        float fade = 1.0 - smoothstep(shadowDistance * 0.82, shadowDistance, dist);
        if (fade <= 0.001) return 1.0;

        vec3 biasedPos = worldPos + worldNormal * ((0.020 + (1.0 - ndl) * 0.07) * SHADOW_BIAS_SCALE);
        vec4 sp = shadowProjection * (shadowModelView * vec4(biasedPos, 1.0));
        sp.xyz /= sp.w;
        sp.xyz = sp.xyz * 0.5 + 0.5;
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) return 1.0;

        float bias = (0.00025 + (1.0 - ndl) * 0.0011) * SHADOW_BIAS_SCALE * (1.0 + dist / max(shadowDistance, 1.0));
        float texel = 1.0 / float(max(shadowMapResolution, 1));
        #if SHADOW_SMOOTHING == 0 || SHADOW_QUALITY == 0
            const int pcfRadius = 0;
        #elif SHADOW_SMOOTHING == 1 || SHADOW_QUALITY == 1
            const int pcfRadius = 1;
        #else
            const int pcfRadius = 2;
        #endif
        float smoothingScale = SHADOW_SMOOTHING == 0 ? 0.65 : (SHADOW_SMOOTHING == 1 ? 1.00 : (SHADOW_SMOOTHING == 2 ? 1.55 : 2.25));
        float penumbraScale = smoothingScale * (SHADOW_QUALITY == 0 ? 1.0 : 1.0 + clamp(dist / max(shadowDistance, 1.0), 0.0, 1.0) * 1.60);
        float rotAngle = (SHADOW_QUALITY == 2 && SHADOW_SMOOTHING >= 2) ? hash12(gl_FragCoord.xy) * 6.28318530718 : 0.0;
        float rotCos = cos(rotAngle);
        float rotSin = sin(rotAngle);
        mat2 pcfRotation = mat2(rotCos, -rotSin, rotSin, rotCos);
        float sum = 0.0;
        float count = 0.0;
        for (int x = -2; x <= 2; x++) {
            if (x < -pcfRadius || x > pcfRadius) continue;
            for (int y = -2; y <= 2; y++) {
                if (y < -pcfRadius || y > pcfRadius) continue;
                vec2 pcfOffset = pcfRotation * (vec2(float(x), float(y)) * texel * penumbraScale);
                float depth = texture2D(shadowtex0, sp.xy + pcfOffset).r;
                sum += step(sp.z - bias, depth);
                count += 1.0;
            }
        }
        return mix(1.0, sum / count, clamp(fade * SHADOW_STRENGTH, 0.0, 1.0));
    #else
        return 1.0;
    #endif
}

float cloudShadowFactor(vec3 worldPos, float skyLight) {
    #if CLOUD_SHADOWS == 1 && defined(OVERWORLD)
        vec3 sunDir = getSunDirectionWorld();
        if (sunDir.y < 0.05 || skyLight < 0.01) return 1.0;
        vec3 worldAbs = worldPos + cameraPosition;
        float cloudPlaneY = 192.0 + CLOUD_HEIGHT_OFFSET;
        float travel = (cloudPlaneY - worldAbs.y) / max(sunDir.y, 0.08);
        if (travel < 0.0) return 1.0;
        vec2 cloudUV = (worldAbs.xz + sunDir.xz * travel) * 0.006 + vec2(frameTimeCounter * 0.0025, 0.0);
        float cover = fbm2(cloudUV);
        float amount = smoothstep(0.52, 0.74, cover) * CLOUD_SHADOW_STRENGTH * skyLight * (1.0 - rainStrength * 0.35);
        return 1.0 - clamp(amount, 0.0, 0.85);
    #else
        return 1.0;
    #endif
}

vec3 lightSurface(vec3 albedo, vec3 normal, vec3 worldPos, vec2 lmcoord, float emissive) {
    vec3 N = normalize(normal);
    float blockLight = clamp(lmcoord.x, 0.0, 1.0);
    float skyLight = clamp(lmcoord.y, 0.0, 1.0);
    #if PIXELATED_LIGHTING == 1
        float pixelLightLevels = float(PIXELATED_LIGHT_LEVELS);
        blockLight = floor(blockLight * pixelLightLevels + 0.5) / pixelLightLevels;
        skyLight = floor(skyLight * pixelLightLevels + 0.5) / pixelLightLevels;
    #endif

    vec3 blockCol = vec3(1.00, 0.52, 0.22) * vec3(BLOCKLIGHT_RED, BLOCKLIGHT_GREEN, BLOCKLIGHT_BLUE) * pow(blockLight, BLOCKLIGHT_FALLOFF) * (1.35 * BLOCKLIGHT_INTENSITY);
    if (BLOCKLIGHT_FLICKER > 0.001 && blockLight > 0.01) {
        vec3 flickerWorld = worldPos + cameraPosition;
        float flickerCell = floor(flickerWorld.x) * 0.37 + floor(flickerWorld.y) * 0.71 + floor(flickerWorld.z) * 0.53;
        float flickerWave = valueNoise2(vec2(flickerCell, frameTimeCounter * 2.20));
        blockCol *= 1.0 + (flickerWave - 0.5) * clamp(BLOCKLIGHT_FLICKER, 0.0, 0.80);
    }

    #if DYNAMIC_HAND_LIGHT == 1
        float heldLevel = float(max(heldBlockLightValue, heldBlockLightValue2));
        if (heldLevel > 0.5) {
            float heldDistance = length(worldPos);
            float heldAtten = clamp(1.0 - heldDistance / max(heldLevel, 1.0), 0.0, 1.0);
            int heldId = heldBlockLightValue >= heldBlockLightValue2 ? heldItemId : heldItemId2;
            vec3 heldColor = vec3(1.00, 0.55, 0.24);
            if (heldId == 2001) heldColor = vec3(0.25, 0.65, 1.10);
            else if (heldId == 2002) heldColor = vec3(1.10, 0.18, 0.10);
            blockCol += heldColor * (pow(heldLevel / 15.0, 2.0) * heldAtten * heldAtten * DYNAMIC_LIGHT_STRENGTH * 1.60);
        }
    #endif

    #if defined(NETHER)
        vec3 ambient = (toLinear(fogColor) * 1.25 + vec3(0.20, 0.045, 0.025)) * NETHER_LIGHT_STRENGTH;
        vec3 direct = vec3(0.0);
    #elif defined(THE_END)
        vec3 endAmbientBase = END_ATMOSPHERE == 0 ? vec3(0.16, 0.13, 0.24) : mix(vec3(0.10, 0.08, 0.20), auroraEndTint() * 5.0, 0.45);
        vec3 ambient = endAmbientBase * (0.30 + 0.70 * skyLight) * END_LIGHT_STRENGTH;
        ambient += vec3(0.05, 0.02, 0.10) * (clamp(-N.y, 0.0, 1.0) * 0.35 * END_LIGHT_STRENGTH);
        vec3 L = normalize(vec3(0.35, 0.85, 0.25));
        float endNdl = max(dot(N, L), 0.0);
        float endWrap = clamp((dot(N, L) + 0.35) / 1.35, 0.0, 1.0);
        vec3 direct = vec3(0.55, 0.50, 0.78) * ((endNdl * 0.55 + endWrap * 0.25) * END_LIGHT_STRENGTH);
    #else
        float day = getDayFactor();
        vec3 ambient = mix(vec3(0.024, 0.035, 0.070), vec3(0.27, 0.33, 0.45), day) * (0.12 + 0.88 * pow(skyLight, 1.6));
        ambient += vec3(0.012, 0.012, 0.014);
        float hemiShade = 0.74 + 0.26 * clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
        ambient *= hemiShade;
        float caveFactor = (1.0 - smoothstep(0.01, 0.30, skyLight)) * (1.0 - clamp(blockLight, 0.0, 1.0));
        ambient *= mix(1.0, 1.0 - clamp(CAVE_DARKNESS, 0.0, 1.0) * 0.88, caveFactor);
        ambient *= mix(1.0, CAVE_LIGHT_MULTIPLIER, caveFactor);

        vec3 sunDir = getSunDirectionWorld();
        vec3 lightDir = getShadowLightDirectionWorld();
        float shadow = getShadow(worldPos, N, skyLight) * cloudShadowFactor(worldPos, skyLight);
        #if PIXELATED_LIGHTING == 1
            float shadowLevels = float(PIXELATED_LIGHT_LEVELS);
            shadow = floor(shadow * shadowLevels + 0.5) / shadowLevels;
        #endif
        ambient *= mix(clamp(SHADOW_LIGHT_MULTIPLIER, 0.0, 1.25), 1.0, shadow);
        float ndl = clamp((dot(N, lightDir) + 0.22) / 1.22, 0.0, 1.0);
        vec3 sunTint = mix(vec3(1.00, 0.32, 0.05), vec3(1.00, 0.84, 0.62), smoothstep(0.02, 0.50, sunDir.y));
        vec3 directCol = mix(vec3(0.35, 0.45, 0.75), sunTint, day);
        float directStrength = mix(0.22, 2.35, day) * SUN_INTENSITY * (1.0 - rainStrength * clamp(RAIN_DARKNESS, 0.0, 1.0));
        vec3 direct = directCol * (ndl * shadow * pow(skyLight, 1.5) * directStrength);
    #endif

    vec3 lightMultiplier = lightingColorMultiplier();
    ambient *= lightMultiplier;
    direct *= lightMultiplier;
    vec3 color = albedo * (ambient + blockCol + direct);
    color += albedo * emissive;
    return color;
}

vec3 applyFog(vec3 color, vec3 worldPos, vec3 viewPos, float skyLight) {
    float dist = length(viewPos);
    float end = max(fogEnd, fogStart + 0.001);
    float fogScale = FOG_STRENGTH;
    #if defined(NETHER)
        fogScale = NETHER_FOG_STRENGTH;
    #endif
    #if defined(THE_END)
        if (END_ATMOSPHERE > 0) fogScale = END_FOG_STRENGTH;
    #endif
    float factor = smoothstep(fogStart, end, dist * fogScale);

    #if defined(OVERWORLD)
        if (isEyeInWater == 0) {
            float worldY = worldPos.y + cameraPosition.y;
            float heightFog = (1.0 - exp(-dist * 0.0038 * FOG_STRENGTH)) * exp(-max(worldY - 58.0, 0.0) * 0.03) * skyLight * HEIGHT_FOG_STRENGTH;
            float rainFog = (1.0 - exp(-dist * 0.0045 * RAIN_FOG_STRENGTH)) * rainStrength * skyLight * 0.55;
            factor = max(factor, rainFog);
            factor = max(factor, heightFog);
        }
    #endif

    vec3 fogTint = toLinear(fogColor);
    if (isEyeInWater == 1) {
        vec3 uwMult = vec3(UNDERWATER_RED, UNDERWATER_GREEN, UNDERWATER_BLUE);
        #if defined(OVERWORLD)
            vec3 deepWater = vec3(0.008, 0.075, 0.190) * (0.12 + 0.88 * getDayFactor());
        #else
            vec3 deepWater = vec3(0.008, 0.075, 0.190);
        #endif
        fogTint = mix(deepWater, fogTint, 0.35) * uwMult;
        factor = 1.0 - exp(-dist * 0.085 * max(FOG_STRENGTH * UNDERWATER_FOG_STRENGTH, 0.05));
    }
    #if defined(THE_END)
        if (END_ATMOSPHERE > 0) {
            fogTint = auroraEndTint() * 1.35;
            float voidFog = (1.0 - exp(-dist * 0.006 * END_FOG_STRENGTH)) * skyLight * 0.35;
            factor = max(factor, voidFog);
        }
    #endif

    fogTint *= atmosphereColorMultiplier();
    return mix(color, fogTint, clamp(factor, 0.0, 1.0));
}
#endif
