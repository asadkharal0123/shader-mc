#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_LINE
#include "/program/line.fsh"
