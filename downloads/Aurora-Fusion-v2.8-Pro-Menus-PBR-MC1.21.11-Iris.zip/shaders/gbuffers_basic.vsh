#version 120
#define VERTEX
#define PROGRAM_BASIC
#include "/program/simple.vsh"
