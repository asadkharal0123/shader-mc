#version 120
#define VERTEX
#define PROGRAM_TERRAIN
#include "/program/forward.vsh"
