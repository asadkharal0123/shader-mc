#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_LIGHTNING
#include "/program/simple.vsh"
