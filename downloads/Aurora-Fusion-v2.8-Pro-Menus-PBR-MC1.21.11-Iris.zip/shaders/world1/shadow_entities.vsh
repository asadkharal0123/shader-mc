#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_ENTITIES
#include "/program/shadow.vsh"
