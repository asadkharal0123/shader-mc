#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_SHADOW_WATER
#include "/program/shadow.vsh"
