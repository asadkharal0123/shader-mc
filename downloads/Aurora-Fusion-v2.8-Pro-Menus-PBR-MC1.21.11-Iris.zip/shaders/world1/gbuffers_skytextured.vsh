#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_SKYTEXTURED
#include "/program/sky.vsh"
