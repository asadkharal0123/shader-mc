#version 120
#define FRAGMENT
#define THE_END
#define END
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_ENTITIES
#include "/program/shadow.fsh"
