#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_BEACONBEAM
#include "/program/simple.vsh"
