#version 120
#define VERTEX
#define THE_END
#define END
#define PROGRAM_COMPOSITE
#include "/program/composite.vsh"
