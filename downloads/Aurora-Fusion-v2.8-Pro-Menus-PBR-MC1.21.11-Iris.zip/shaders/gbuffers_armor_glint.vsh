#version 120
#define VERTEX
#define PROGRAM_GLINT
#include "/program/simple.vsh"
