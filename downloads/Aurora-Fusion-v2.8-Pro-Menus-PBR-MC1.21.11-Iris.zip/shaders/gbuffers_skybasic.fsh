#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_SKYBASIC
#include "/program/sky.fsh"
