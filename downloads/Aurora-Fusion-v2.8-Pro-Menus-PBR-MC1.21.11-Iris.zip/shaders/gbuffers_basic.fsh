#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_BASIC
#include "/program/simple.fsh"
