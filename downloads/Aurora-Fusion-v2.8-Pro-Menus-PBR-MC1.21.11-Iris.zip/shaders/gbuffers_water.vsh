#version 120
#define VERTEX
#define PROGRAM_WATER
#include "/program/water.vsh"
