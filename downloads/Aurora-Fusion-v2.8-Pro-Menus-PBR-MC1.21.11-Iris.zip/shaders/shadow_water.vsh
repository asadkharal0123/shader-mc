#version 120
#define VERTEX
#define PROGRAM_SHADOW_WATER
#include "/program/shadow.vsh"
