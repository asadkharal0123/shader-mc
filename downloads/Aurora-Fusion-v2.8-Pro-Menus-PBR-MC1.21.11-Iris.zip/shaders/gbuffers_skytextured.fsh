#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_SKYTEXTURED
#include "/program/sky.fsh"
