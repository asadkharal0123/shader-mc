#version 120
#define VERTEX
#define PROGRAM_COMPOSITE
#include "/program/composite.vsh"
