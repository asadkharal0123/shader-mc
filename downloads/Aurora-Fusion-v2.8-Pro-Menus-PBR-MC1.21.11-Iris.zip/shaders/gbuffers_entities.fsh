#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_ENTITIES
#include "/program/forward.fsh"
