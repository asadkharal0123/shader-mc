#version 120
#define VERTEX
#define PROGRAM_SHADOW
#include "/program/shadow.vsh"
