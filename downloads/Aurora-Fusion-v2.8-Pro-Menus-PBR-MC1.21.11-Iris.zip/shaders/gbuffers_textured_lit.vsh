#version 120
#define VERTEX
#define PROGRAM_TEXTURED_LIT
#include "/program/forward.vsh"
