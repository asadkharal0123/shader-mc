#version 120
#define VERTEX
#define PROGRAM_DAMAGEDBLOCK
#include "/program/forward.vsh"
