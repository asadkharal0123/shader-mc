#version 120
#define VERTEX
#define PROGRAM_TEXTURED
#include "/program/simple.vsh"
