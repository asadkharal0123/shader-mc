#version 120
#define VERTEX
#define PROGRAM_SKYTEXTURED
#include "/program/sky.vsh"
