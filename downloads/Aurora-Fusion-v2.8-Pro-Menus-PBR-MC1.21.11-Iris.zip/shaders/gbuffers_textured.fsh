#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_TEXTURED
#include "/program/simple.fsh"
