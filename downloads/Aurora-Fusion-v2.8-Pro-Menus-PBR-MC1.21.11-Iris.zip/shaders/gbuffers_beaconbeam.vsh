#version 120
#define VERTEX
#define PROGRAM_BEACONBEAM
#include "/program/simple.vsh"
