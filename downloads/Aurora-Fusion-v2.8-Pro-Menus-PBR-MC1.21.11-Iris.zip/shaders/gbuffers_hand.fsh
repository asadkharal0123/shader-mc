#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_HAND
#include "/program/forward.fsh"
