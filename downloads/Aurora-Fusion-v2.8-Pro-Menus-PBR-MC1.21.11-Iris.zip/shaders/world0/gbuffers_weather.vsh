#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_WEATHER
#include "/program/forward.vsh"
