#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_BEACONBEAM
#include "/program/simple.vsh"
