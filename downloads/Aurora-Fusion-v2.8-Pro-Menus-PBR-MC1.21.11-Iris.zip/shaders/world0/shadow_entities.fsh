#version 120
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_ENTITIES
#include "/program/shadow.fsh"
