#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_ENTITIES
#include "/program/shadow.vsh"
