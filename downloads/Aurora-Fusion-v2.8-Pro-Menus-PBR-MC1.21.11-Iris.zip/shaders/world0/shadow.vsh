#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_SHADOW
#include "/program/shadow.vsh"
