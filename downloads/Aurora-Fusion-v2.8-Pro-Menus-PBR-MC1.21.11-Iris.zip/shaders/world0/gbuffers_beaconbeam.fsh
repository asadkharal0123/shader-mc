#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_BEACONBEAM
#include "/program/simple.fsh"
