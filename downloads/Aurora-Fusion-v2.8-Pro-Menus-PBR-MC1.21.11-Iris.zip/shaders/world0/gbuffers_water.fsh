#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_WATER
#include "/program/water.fsh"
