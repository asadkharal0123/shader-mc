#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_TERRAIN
#include "/program/forward.vsh"
