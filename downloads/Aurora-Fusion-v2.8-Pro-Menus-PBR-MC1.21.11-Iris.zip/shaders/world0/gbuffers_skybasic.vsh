#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_SKYBASIC
#include "/program/sky.vsh"
