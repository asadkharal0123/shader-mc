#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_DAMAGEDBLOCK
#include "/program/forward.fsh"
