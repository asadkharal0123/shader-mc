#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_SKYTEXTURED
#include "/program/sky.fsh"
