#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_SKYTEXTURED
#include "/program/sky.vsh"
