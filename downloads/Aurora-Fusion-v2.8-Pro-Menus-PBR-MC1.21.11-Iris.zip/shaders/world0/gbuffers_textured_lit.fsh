#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_TEXTURED_LIT
#include "/program/forward.fsh"
