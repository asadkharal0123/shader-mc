#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_TEXTURED
#include "/program/simple.vsh"
