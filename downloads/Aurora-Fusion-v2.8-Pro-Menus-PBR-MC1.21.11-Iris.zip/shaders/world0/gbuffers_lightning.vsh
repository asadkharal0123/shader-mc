#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_LIGHTNING
#include "/program/simple.vsh"
