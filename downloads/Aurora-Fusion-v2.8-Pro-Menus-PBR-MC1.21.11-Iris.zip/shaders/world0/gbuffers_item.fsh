#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define OVERWORLD
#define PROGRAM_ITEM
#include "/program/forward.fsh"
