#version 120
#define VERTEX
#define OVERWORLD
#define PROGRAM_GLINT
#include "/program/simple.vsh"
