#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vWorldAbsolute;
varying vec3 vViewPos;
varying vec3 vWorldNormal;

void main() {
    vec3 pos = gl_Vertex.xyz;

    #if defined(PROGRAM_CLOUDS)
        pos.y += CLOUD_HEIGHT_OFFSET;
        pos.x += frameTimeCounter * (CLOUD_SPEED - 1.0) * 0.55;
    #endif

    vec4 viewPos = gl_ModelViewMatrix * vec4(pos, 1.0);
    vViewPos = viewPos.xyz;
    vWorldPos = (gbufferModelViewInverse * viewPos).xyz;
    vWorldAbsolute = vWorldPos + cameraPosition;
    #if defined(PROGRAM_CLOUDS)
        vWorldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
    #else
        vWorldNormal = vec3(0.0, 1.0, 0.0);
    #endif
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;
    gl_Position = gl_ProjectionMatrix * viewPos;
}
