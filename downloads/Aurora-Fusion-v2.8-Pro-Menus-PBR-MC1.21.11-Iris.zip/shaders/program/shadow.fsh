#include "/lib/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec4 vColor;
varying float vBlockId;
varying float vCamDist;

void main() {
    #if defined(PROGRAM_SHADOW_ENTITIES)
        if (ENTITY_SHADOWS == 0) discard;
        if (PLAYER_SHADOW == 0 && vCamDist < 2.5) discard;
    #endif
    int bid = int(vBlockId + 0.5);
    #if !defined(PROGRAM_SHADOW_WATER)
        if (bid == 1001) {
            int leafMode = LEAF_SHADOW_OPTIMIZATION;
            if (leafMode == 0) leafMode = SHADOW_QUALITY == 0 ? 2 : 1;
            if (leafMode == 3) discard;
            if (leafMode == 2) {
                float leafChecker = mod(floor(gl_FragCoord.x) + floor(gl_FragCoord.y), 2.0);
                if (leafChecker < 0.5) discard;
            }
        }
    #endif
    float alpha = texture2D(gtexture, texcoord).a * vColor.a;
    #if defined(PROGRAM_SHADOW_WATER)
        if (bid != 1011 && bid != 1015) discard;
        if (alpha < 0.10) discard;
    #else
        if (alpha < alphaTestRef) discard;
    #endif
    gl_FragData[0] = vec4(1.0);
}
