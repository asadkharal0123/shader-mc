#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#if RP_SUPPORT == 2
uniform sampler2D normals;
uniform sampler2D specular;
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;
varying float vChunkFade;
#if RP_SUPPORT == 2
varying vec3 vWorldTangent;
varying float vTangentHandedness;
#endif

float oreGlowMask(vec3 srgb) {
    float maxc = max(max(srgb.r, srgb.g), srgb.b);
    float minc = min(min(srgb.r, srgb.g), srgb.b);
    float sat = maxc - minc;
    float colored = smoothstep(0.08, 0.30, sat);
    float redstone = smoothstep(0.25, 0.55, srgb.r - max(srgb.g, srgb.b));
    float paleSpeckle = smoothstep(0.45, 0.85, maxc) * smoothstep(0.03, 0.16, sat);
    return clamp(max(colored, redstone) * smoothstep(0.12, 0.35, maxc) + paleSpeckle * 0.35, 0.0, 1.0);
}

float dragonEggGlowMask(vec3 srgb) {
    float purple = smoothstep(0.05, 0.28, ((srgb.r + srgb.b) * 0.5) - srgb.g);
    float spots = smoothstep(0.12, 0.45, max(srgb.r, srgb.b));
    return clamp(purple * spots + 0.12, 0.0, 1.0);
}

void main() {
    gl_FragData[1] = vec4(0.0);
    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;

    #if defined(PROGRAM_TERRAIN)
        if (CHUNK_FADE == 1 && vChunkFade >= 0.0 && vChunkFade < 0.999 && hash12(gl_FragCoord.xy) > vChunkFade) discard;
    #endif

    #if defined(PROGRAM_DAMAGEDBLOCK)
        gl_FragData[0] = vec4(vec3(0.0), alpha);
        return;
    #endif

    vec3 albedoSrgb = tex.rgb * vColor.rgb;
    #if defined(PROGRAM_ENTITIES) || defined(PROGRAM_ITEM)
        albedoSrgb = mix(albedoSrgb, entityColor.rgb, entityColor.a);
    #endif
    vec3 albedo = toLinear(albedoSrgb);

    vec3 N = normalize(vWorldNormal);
    if (!gl_FrontFacing) N = -N;

    vec3 pbrF0 = vec3(0.04);
    float pbrSmoothness = 0.0;
    float pbrEmissive = 0.0;
    float pbrMaterialAo = 1.0;
    float pbrPorosity = 0.0;
    #if RP_SUPPORT == 2
        vec4 normalTex = texture2D(normals, texcoord);
        vec4 specularTex = texture2D(specular, texcoord);
        bool labPbr = PBR_FORMAT == 1;
        #if PBR_FORMAT == 0
            #ifdef MC_TEXTURE_FORMAT_LAB_PBR
                labPbr = true;
            #endif
        #endif
        vec3 tangentNormal;
        if (labPbr) {
            vec2 normalXY = normalTex.rg * 2.0 - 1.0;
            normalXY.y = -normalXY.y;
            tangentNormal = vec3(normalXY, sqrt(max(1.0 - dot(normalXY, normalXY), 0.0)));
            pbrMaterialAo = clamp(normalTex.b, 0.0, 1.0);
        } else {
            tangentNormal = normalTex.rgb * 2.0 - 1.0;
            tangentNormal.y = -tangentNormal.y;
            if (length(tangentNormal) > 0.001) tangentNormal = normalize(tangentNormal);
        }
        if (PBR_NORMAL_STRENGTH > 0.001) {
            vec3 tangentVec = vWorldTangent - N * dot(N, vWorldTangent);
            if (length(tangentVec) > 0.001) {
                vec3 pbrTangent = normalize(tangentVec);
                vec3 pbrBitangent = normalize(cross(pbrTangent, N) * vTangentHandedness);
                vec3 mappedNormal = normalize(pbrTangent * (tangentNormal.x * PBR_NORMAL_STRENGTH) + pbrBitangent * (tangentNormal.y * PBR_NORMAL_STRENGTH) + N * max(tangentNormal.z, 0.05));
                if (dot(mappedNormal, N) > 0.0) N = mappedNormal;
            }
        }
        pbrSmoothness = clamp(specularTex.r, 0.0, 1.0);
        if (labPbr) {
            bool metalCode = specularTex.g >= 230.0 / 255.0;
            pbrF0 = metalCode ? max(albedo, vec3(0.04)) : vec3(clamp(specularTex.g, 0.0, 0.90));
            pbrEmissive = specularTex.a < 0.996 ? specularTex.a : 0.0;
            if (specularTex.b <= 64.0 / 255.0) pbrPorosity = specularTex.b / (64.0 / 255.0);
        } else {
            float metalness = clamp(specularTex.g, 0.0, 1.0);
            pbrF0 = mix(vec3(0.04), max(albedo, vec3(0.04)), metalness);
            pbrEmissive = clamp(specularTex.b, 0.0, 1.0);
        }
    #endif

    #if defined(PROGRAM_WEATHER)
        vec3 weatherColor = albedo * (0.45 + 0.55 * clamp(lmcoord.y, 0.0, 1.0)) * WEATHER_BRIGHTNESS;
        weatherColor = applyFog(weatherColor, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(weatherColor, clamp(alpha * 0.65 * WEATHER_OPACITY, 0.0, 1.0));
        return;
    #endif

    int blockId = int(vBlockId + 0.5);
    float emissive = blockId == 1010 ? 1.25 * (RP_SUPPORT == 1 ? INTEGRATED_EMISSIVE_STRENGTH : 1.0) : 0.0;
    vec3 color = lightSurface(albedo, N, vWorldPos, lmcoord, emissive);
    float integratedEmissiveScale = RP_SUPPORT == 1 ? INTEGRATED_EMISSIVE_STRENGTH : 1.0;

    #if RP_SUPPORT == 2
        color *= mix(1.0, pbrMaterialAo, clamp(PBR_AO_STRENGTH, 0.0, 1.0));
        if (pbrPorosity > 0.001) {
            color *= 1.0 - pbrPorosity * wetness * clamp(lmcoord.y, 0.0, 1.0) * clamp(PBR_POROSITY_EFFECT, 0.0, 1.0) * 0.45;
        }
        vec3 pbrViewDir = normalize(-vWorldPos);
        vec3 pbrLightDir = getShadowLightDirectionWorld();
        #if defined(THE_END)
            pbrLightDir = normalize(vec3(0.35, 0.85, 0.25));
        #endif
        vec3 pbrHalfDir = normalize(pbrLightDir + pbrViewDir);
        float pbrExponent = mix(6.0, 220.0, pbrSmoothness * pbrSmoothness);
        float pbrLightVis = clamp(pow(clamp(lmcoord.y, 0.0, 1.0), 1.20) + pow(clamp(lmcoord.x, 0.0, 1.0), 2.0) * 0.35, 0.0, 1.0);
        #if defined(OVERWORLD)
            pbrLightVis *= 0.12 + 0.88 * getDayFactor();
        #elif defined(THE_END)
            pbrLightVis = max(pbrLightVis, 0.45);
        #else
            pbrLightVis = max(pbrLightVis, 0.25);
        #endif
        float pbrSpecular = pow(max(dot(N, pbrHalfDir), 0.0), pbrExponent) * pbrLightVis;
        color += pbrF0 * (pbrSpecular * (0.25 + pbrSmoothness * 1.35) * PBR_SPECULAR_STRENGTH);
        color += albedo * (pbrEmissive * pbrEmissive * PBR_EMISSIVE_STRENGTH * 2.50);
    #elif RP_SUPPORT == 1
        float integratedSmooth = blockId == 1014 ? 0.65 : (blockId == 1012 ? 0.28 : (blockId == 1013 ? 0.20 : 0.06));
        if (blockId >= 1001 && blockId <= 1004) integratedSmooth = 0.02;
        vec3 integratedViewDir = normalize(-vWorldPos);
        vec3 integratedLightDir = getShadowLightDirectionWorld();
        #if defined(THE_END)
            integratedLightDir = normalize(vec3(0.35, 0.85, 0.25));
        #endif
        float integratedSpec = pow(max(dot(N, normalize(integratedLightDir + integratedViewDir)), 0.0), mix(18.0, 110.0, integratedSmooth));
        float integratedVis = clamp(lmcoord.y + lmcoord.x * 0.25, 0.0, 1.0);
        color += vec3(1.00, 0.92, 0.78) * (integratedSpec * integratedSmooth * integratedVis * INTEGRATED_SPECULAR_STRENGTH * 0.55);
    #endif

    #if RP_SUPPORT > 0 && GLOWING_ORES == 1
        if (blockId == 1012) {
            color += toLinear(albedoSrgb) * (oreGlowMask(albedoSrgb) * ORE_GLOW_STRENGTH * 2.40);
        }
    #endif
    #if RP_SUPPORT > 0 && GLOWING_DRAGON_EGG == 1
        if (blockId == 1013) {
            float eggMask = dragonEggGlowMask(albedoSrgb);
            color += vec3(0.38, 0.05, 0.85) * (eggMask * DRAGON_EGG_GLOW_STRENGTH * 1.80);
            color += toLinear(albedoSrgb) * (eggMask * DRAGON_EGG_GLOW_STRENGTH * 0.80);
        }
    #endif

    if (blockId == 1016) {
        float soulMask = smoothstep(0.20, 0.75, luminance(albedoSrgb));
        color += vec3(0.20, 0.55, 1.05) * ((soulMask * 1.10 + 0.10) * integratedEmissiveScale);
    } else if (blockId == 1017) {
        float redMask = smoothstep(0.20, 0.75, luminance(albedoSrgb));
        color += vec3(1.05, 0.16, 0.08) * ((redMask * 0.95 + 0.08) * integratedEmissiveScale);
    }

    if (blockId == 1018) {
        vec3 portalWorld = vWorldPos + cameraPosition;
        float portalWave = 0.5 + 0.5 * sin((portalWorld.x + portalWorld.y * 1.70 + portalWorld.z) * 2.10 + frameTimeCounter * 2.40);
        float portalEffect = SPECIAL_PORTAL_EFFECTS == 1 ? 1.0 : 0.0;
        vec3 portalColor = albedo * (1.65 + portalEffect * portalWave * 0.45) + vec3(0.14, 0.02, 0.30) * (portalEffect * portalWave * 0.35);
        color = mix(color, portalColor, 0.72);
    }

    #if RP_SUPPORT > 0 && GLASS_REFLECTIONS == 1
        if (blockId == 1011 || blockId == 1014 || blockId == 1015) {
            vec3 viewDirWorld = normalize(-vWorldPos);
            float glassFresnel = 0.04 + 0.96 * pow(1.0 - max(dot(N, viewDirWorld), 0.0), 5.0);
            bool skyReflectionEnabled = SKY_EFFECT_REFLECTIONS == 2 || (SKY_EFFECT_REFLECTIONS == 1 && WATER_REFLECTIONS > 0);
            vec3 glassReflection = skyReflectionEnabled ? skyGradient(reflect(-viewDirWorld, N)) : vec3(0.0);
            vec3 glassLightDir = getShadowLightDirectionWorld();
            #if defined(THE_END)
                glassLightDir = normalize(vec3(0.35, 0.85, 0.25));
            #endif
            float specPower = blockId == 1011 ? 90.0 : (blockId == 1015 ? 70.0 : 55.0);
            float reflectionStrength = blockId == 1011 ? GLASS_REFLECTION_STRENGTH : (blockId == 1015 ? ICE_REFLECTION_STRENGTH : POLISHED_REFLECTION_STRENGTH);
            float glassSkyVis = pow(clamp(lmcoord.y, 0.0, 1.0), 1.25);
            #if defined(THE_END)
                glassSkyVis = max(glassSkyVis, 0.65);
            #endif
            float glassSpec = pow(max(dot(N, normalize(glassLightDir + viewDirWorld)), 0.0), specPower) * glassSkyVis;
            float glassLightAmount = clamp(lmcoord.y + 0.15, 0.0, 1.0);
            color += (glassReflection * (glassFresnel * glassSkyVis) + vec3(1.00, 0.90, 0.75) * (glassSpec * 0.45)) * (reflectionStrength * glassLightAmount);
        }
    #endif

    color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);
    gl_FragData[0] = vec4(color, alpha);
}
