#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/waving.glsl"

uniform mat4 shadowModelViewInverse;

varying vec2 texcoord;
varying vec4 vColor;
varying float vBlockId;
varying float vCamDist;

void main() {
    vec3 pos = applyWaving(gl_Vertex.xyz);
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    vBlockId = mc_Entity.x;
    vec4 shadowViewPos = gl_ModelViewMatrix * vec4(pos, 1.0);
    vCamDist = length((shadowModelViewInverse * shadowViewPos).xyz);
    gl_Position = gl_ProjectionMatrix * shadowViewPos;
}
