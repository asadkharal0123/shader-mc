#include "/lib/settings.glsl"

uniform float viewWidth;
uniform float viewHeight;

varying vec4 vColor;

void main() {
    vColor = gl_Color;
    float shrink = 1.0 - (1.0 / 256.0);

    vec4 startView = gl_ModelViewMatrix * vec4(gl_Vertex.xyz, 1.0);
    vec4 endView = gl_ModelViewMatrix * vec4(gl_Vertex.xyz + gl_Normal, 1.0);
    startView.xyz *= shrink;
    endView.xyz *= shrink;

    vec4 startClip = gl_ProjectionMatrix * startView;
    vec4 endClip = gl_ProjectionMatrix * endView;
    vec3 startNdc = startClip.xyz / startClip.w;
    vec3 endNdc = endClip.xyz / endClip.w;

    vec2 resolution = vec2(viewWidth, viewHeight);
    vec2 dir = normalize((endNdc.xy - startNdc.xy) * resolution);
    vec2 offset = vec2(-dir.y, dir.x) * (2.0 / resolution);
    if (offset.x < 0.0) offset = -offset;

    startNdc.xy += ((gl_VertexID % 2) == 0) ? offset : -offset;
    gl_Position = vec4(startNdc * startClip.w, startClip.w);
}
