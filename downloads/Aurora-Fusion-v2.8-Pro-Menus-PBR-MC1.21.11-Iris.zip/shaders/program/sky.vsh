#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec4 vColor;
varying vec3 vWorldDir;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vWorldDir = (gbufferModelViewInverse * viewPos).xyz;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    gl_Position = gl_ProjectionMatrix * viewPos;
}
