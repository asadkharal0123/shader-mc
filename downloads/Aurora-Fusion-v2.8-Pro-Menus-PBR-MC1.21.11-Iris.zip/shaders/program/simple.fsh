#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vWorldAbsolute;
varying vec3 vViewPos;
varying vec3 vWorldNormal;

void main() {
    gl_FragData[1] = vec4(0.0);

    #if defined(PROGRAM_BASIC)
        vec3 basicColor = toLinear(vColor.rgb);
        basicColor = applyFog(basicColor, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(basicColor, vColor.a);
        return;
    #endif

    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;
    vec3 color = toLinear(tex.rgb * vColor.rgb);

    #if defined(PROGRAM_BEACONBEAM)
        color *= 1.85;
    #elif defined(PROGRAM_GLINT)
        color *= vec3(0.70, 0.50, 1.30) * 1.80;
    #elif defined(PROGRAM_SPIDEREYES)
        color *= 2.00;
    #elif defined(PROGRAM_LIGHTNING)
        color = toLinear(vColor.rgb) * (4.00 * LIGHTNING_INTENSITY);
        alpha = vColor.a;
    #elif defined(PROGRAM_CLOUDS)
        float day = getDayFactor();
        vec3 cloudNormal = normalize(vWorldNormal);
        float topness = clamp(cloudNormal.y * 0.5 + 0.5, 0.0, 1.0);
        float cloudShade = 1.0;
        float erosion = 1.0;

        #if CLOUD_MODE == 1
            cloudShade = mix(0.66, 1.12, topness);
            erosion = 0.84 + 0.16 * valueNoise2(vWorldAbsolute.xz * 0.075);
        #elif CLOUD_MODE == 2
            cloudShade = mix(0.58, 1.18, topness);
            float puffNoise = fbm2(vWorldAbsolute.xz * 0.045 + vec2(frameTimeCounter * 0.004, 0.0));
            erosion = smoothstep(0.24, 0.64, puffNoise + (topness - 0.5) * 0.14);
        #elif CLOUD_MODE == 3
            if (abs(cloudNormal.y) < 0.55) discard;
            cloudShade = mix(0.70, 1.08, topness);
        #elif CLOUD_MODE == 4
            cloudShade = mix(0.52, 1.22, topness);
            float detailNoise = fbm2(vWorldAbsolute.xz * 0.030 + vec2(frameTimeCounter * 0.003, 0.0));
            erosion = smoothstep(0.18, 0.62, detailNoise + (topness - 0.5) * 0.20);
        #elif CLOUD_MODE == 5
            if (abs(cloudNormal.y) < 0.55) discard;
            cloudShade = mix(0.78, 1.05, topness);
            float wispNoise = fbm2(vec2(vWorldAbsolute.x * 0.012, vWorldAbsolute.z * 0.055) + vec2(frameTimeCounter * 0.002, 0.0));
            erosion = smoothstep(0.35, 0.75, wispNoise) * 0.75;
        #endif

        vec3 sunDir = getSunDirectionWorld();
        float twilight = 1.0 - smoothstep(0.0, 0.32, abs(sunDir.y));
        float sunGate = smoothstep(-0.06, 0.18, sunDir.y);
        float rainDim = 1.0 - rainStrength * 0.42;
        cloudShade = mix(0.95, cloudShade, clamp(day + twilight * 0.6, 0.0, 1.0));
        color *= mix(0.22, 1.14, day) * cloudShade * CLOUD_BRIGHTNESS * rainDim;
        color += vec3(0.010, 0.015, 0.030) * ((1.0 - day) * CLOUD_BRIGHTNESS);
        color += vec3(0.55, 0.20, 0.08) * (twilight * sunGate * 0.20 * topness);
        vec3 cloudViewDir = normalize(vWorldPos);
        float cloudForward = pow(max(dot(cloudViewDir, sunDir), 0.0), 6.0);
        color += vec3(1.00, 0.75, 0.50) * (cloudForward * sunGate * 0.16 * CLOUD_BRIGHTNESS);
        vec2 cloudCell = floor(vWorldAbsolute.xz / 12.0);
        float cloudCellHash = hash12(cloudCell * 1.37);
        float cloudAmountFade = cloudCellHash <= CLOUD_AMOUNT ? 1.0 : 0.0;
        alpha *= CLOUD_OPACITY * erosion * cloudAmountFade;
        if (alpha < 0.003) discard;
    #else
        color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);
    #endif

    gl_FragData[0] = vec4(color, alpha);
}
