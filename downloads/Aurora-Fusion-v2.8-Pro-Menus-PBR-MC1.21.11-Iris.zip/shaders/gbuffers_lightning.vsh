#version 120
#define VERTEX
#define PROGRAM_LIGHTNING
#include "/program/simple.vsh"
