#version 120
#define VERTEX
#define PROGRAM_CLOUDS
#include "/program/simple.vsh"
