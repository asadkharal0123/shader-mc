#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_WEATHER
#include "/program/forward.fsh"
