#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_PARTICLES
#include "/program/forward.fsh"
