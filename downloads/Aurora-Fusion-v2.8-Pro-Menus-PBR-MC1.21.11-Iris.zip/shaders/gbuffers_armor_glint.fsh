#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_GLINT
#include "/program/simple.fsh"
