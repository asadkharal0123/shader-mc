#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_COMPOSITE
#include "/program/composite.fsh"
