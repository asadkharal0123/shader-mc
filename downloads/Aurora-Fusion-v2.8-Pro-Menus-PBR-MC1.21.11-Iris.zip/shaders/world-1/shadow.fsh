#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_SHADOW
#include "/program/shadow.fsh"
