#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define NETHER
#define PROGRAM_TEXTURED
#include "/program/simple.fsh"
