#version 120
#define VERTEX
#define NETHER
#define PROGRAM_SKYBASIC
#include "/program/sky.vsh"
