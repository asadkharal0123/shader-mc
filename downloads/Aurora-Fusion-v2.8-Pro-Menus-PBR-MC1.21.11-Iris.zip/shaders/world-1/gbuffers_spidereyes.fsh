#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define NETHER
#define PROGRAM_SPIDEREYES
#include "/program/simple.fsh"
