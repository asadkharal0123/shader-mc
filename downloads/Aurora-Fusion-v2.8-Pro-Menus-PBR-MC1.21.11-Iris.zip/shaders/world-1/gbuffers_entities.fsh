#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define NETHER
#define PROGRAM_ENTITIES
#include "/program/forward.fsh"
