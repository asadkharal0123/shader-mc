#version 120
#define VERTEX
#define NETHER
#define PROGRAM_TEXTURED
#include "/program/simple.vsh"
