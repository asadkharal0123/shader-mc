#version 120
#define VERTEX
#define NETHER
#define PROGRAM_GLINT
#include "/program/simple.vsh"
