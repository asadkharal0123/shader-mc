#version 120
#define VERTEX
#define NETHER
#define PROGRAM_SHADOW
#include "/program/shadow.vsh"
