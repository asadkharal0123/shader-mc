#version 120
#define VERTEX
#define NETHER
#define PROGRAM_SKYTEXTURED
#include "/program/sky.vsh"
