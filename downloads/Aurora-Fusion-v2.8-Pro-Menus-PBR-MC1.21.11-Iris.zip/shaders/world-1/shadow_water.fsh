#version 120
#define FRAGMENT
#define NETHER
#define PROGRAM_SHADOW_WATER
#include "/program/shadow.fsh"
