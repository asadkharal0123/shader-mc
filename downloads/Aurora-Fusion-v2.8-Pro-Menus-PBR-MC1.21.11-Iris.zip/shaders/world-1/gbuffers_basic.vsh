#version 120
#define VERTEX
#define NETHER
#define PROGRAM_BASIC
#include "/program/simple.vsh"
