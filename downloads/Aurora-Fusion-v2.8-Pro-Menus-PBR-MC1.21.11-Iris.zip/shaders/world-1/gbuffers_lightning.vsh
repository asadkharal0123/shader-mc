#version 120
#define VERTEX
#define NETHER
#define PROGRAM_LIGHTNING
#include "/program/simple.vsh"
