#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define NETHER
#define PROGRAM_TERRAIN
#include "/program/forward.fsh"
