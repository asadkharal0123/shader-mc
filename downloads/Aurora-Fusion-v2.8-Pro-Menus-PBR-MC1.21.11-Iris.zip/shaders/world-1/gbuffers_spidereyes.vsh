#version 120
#define VERTEX
#define NETHER
#define PROGRAM_SPIDEREYES
#include "/program/simple.vsh"
