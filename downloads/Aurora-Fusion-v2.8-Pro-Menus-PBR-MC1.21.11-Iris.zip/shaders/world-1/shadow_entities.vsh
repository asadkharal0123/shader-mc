#version 120
#define VERTEX
#define NETHER
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_ENTITIES
#include "/program/shadow.vsh"
