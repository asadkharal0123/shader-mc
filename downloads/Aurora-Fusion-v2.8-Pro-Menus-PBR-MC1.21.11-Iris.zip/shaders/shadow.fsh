#version 120
#define FRAGMENT
#define PROGRAM_SHADOW
#include "/program/shadow.fsh"
