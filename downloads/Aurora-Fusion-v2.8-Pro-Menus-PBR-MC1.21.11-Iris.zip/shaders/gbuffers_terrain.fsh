#version 120
/* DRAWBUFFERS:01 */
#define FRAGMENT
#define PROGRAM_TERRAIN
#include "/program/forward.fsh"
