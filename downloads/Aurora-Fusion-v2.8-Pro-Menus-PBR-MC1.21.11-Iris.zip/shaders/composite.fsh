#version 120
#define FRAGMENT
#define PROGRAM_COMPOSITE
#include "/program/composite.fsh"
