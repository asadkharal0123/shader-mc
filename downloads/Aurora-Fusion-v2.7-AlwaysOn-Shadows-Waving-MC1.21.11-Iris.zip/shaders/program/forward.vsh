#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#if defined(PROGRAM_TERRAIN)
    #include "/lib/waving.glsl"
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;
varying float vChunkFade;

void main() {
    vec3 pos = gl_Vertex.xyz;

    #if defined(PROGRAM_TERRAIN)
        vBlockId = mc_Entity.x;
        pos = applyWaving(pos);
    #else
        vBlockId = 0.0;
    #endif

    #if defined(PROGRAM_WEATHER)
        if (WAVING_WEATHER == 1) {
            float wPhase = pos.x * 0.50 + pos.y * 0.35 + pos.z * 0.50;
            pos.x += sin(frameTimeCounter * WAVING_SPEED * 2.0 + wPhase) * 0.08 * WAVING_INTENSITY;
            pos.z += cos(frameTimeCounter * WAVING_SPEED * 1.7 + wPhase * 1.3) * 0.06 * WAVING_INTENSITY;
        }
    #endif

    vec4 viewPos = gl_ModelViewMatrix * vec4(pos, 1.0);
    vViewPos = viewPos.xyz;
    vWorldPos = (gbufferModelViewInverse * viewPos).xyz;
    vWorldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;

    #if defined(PROGRAM_TERRAIN) && defined(IRIS_FEATURE_FADE_VARIABLE)
        vChunkFade = mc_chunkFade;
    #else
        vChunkFade = 1.0;
    #endif

    gl_Position = gl_ProjectionMatrix * viewPos;
}
