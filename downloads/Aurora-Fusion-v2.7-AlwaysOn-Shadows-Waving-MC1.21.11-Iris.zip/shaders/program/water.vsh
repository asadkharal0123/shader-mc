#include "/lib/settings.glsl"
#include "/lib/common.glsl"

attribute vec4 mc_Entity;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vWorldAbsolute;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;

void main() {
    vec3 pos = gl_Vertex.xyz;
    #if WATER_DETAIL > 0
        int wvId = int(mc_Entity.x + 0.5);
        if (WAVING_WATER_HEIGHT == 1 && wvId != 1010 && wvId != 1011 && wvId != 1015 && gl_Normal.y > 0.5) {
            vec3 worldAbs = pos + cameraPosition;
            float wt = frameTimeCounter * WAVING_SPEED;
            float wave = sin(worldAbs.x * 1.4 + wt * 1.6) + sin(worldAbs.z * 1.1 - wt * 1.3);
            pos.y += wave * 0.012 * float(WATER_DETAIL) * WATER_WAVE_STRENGTH * WAVING_INTENSITY;
        }
    #endif

    vec4 viewPos = gl_ModelViewMatrix * vec4(pos, 1.0);
    vViewPos = viewPos.xyz;
    vWorldPos = (gbufferModelViewInverse * viewPos).xyz;
    vWorldAbsolute = vWorldPos + cameraPosition;
    vWorldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;
    vBlockId = mc_Entity.x;
    gl_Position = gl_ProjectionMatrix * viewPos;
}
