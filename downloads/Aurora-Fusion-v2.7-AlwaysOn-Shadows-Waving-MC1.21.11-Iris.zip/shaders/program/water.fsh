#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vWorldAbsolute;
varying vec3 vViewPos;
varying vec3 vWorldNormal;
varying float vBlockId;

vec3 applyWaterColorMode(vec3 albedo) {
    #if WATER_COLOR_MODE == 1
        return albedo * vec3(0.55, 0.78, 1.18);
    #elif WATER_COLOR_MODE == 2
        return albedo * vec3(0.45, 1.05, 1.10);
    #elif WATER_COLOR_MODE == 3
        return albedo * vec3(0.55, 1.10, 0.70);
    #elif WATER_COLOR_MODE == 4
        return albedo * vec3(1.15, 0.50, 0.45);
    #elif WATER_COLOR_MODE == 5
        return albedo * vec3(0.80, 0.55, 1.20);
    #else
        return albedo;
    #endif
}

vec3 auroraCloudReflection(vec3 reflDir, vec3 worldPos, float skyVis) {
    #if defined(OVERWORLD)
        if (reflDir.y < 0.03 || skyVis < 0.01) return vec3(0.0);
        vec3 worldAbs = worldPos + cameraPosition;
        float cloudPlaneY = 192.0 + CLOUD_HEIGHT_OFFSET;
        float travel = (cloudPlaneY - worldAbs.y) / max(reflDir.y, 0.08);
        if (travel < 0.0) return vec3(0.0);
        vec2 cloudHit = worldAbs.xz + reflDir.xz * travel;
        vec2 cloudCell = floor(cloudHit / 12.0);
        if (hash12(cloudCell * 1.37) > CLOUD_AMOUNT) return vec3(0.0);
        float cover = smoothstep(0.48, 0.68, fbm2(cloudHit * 0.006 + vec2(frameTimeCounter * 0.0025, 0.0)));
        vec3 cloudCol = mix(vec3(0.035, 0.050, 0.090), vec3(1.02), getDayFactor()) * CLOUD_BRIGHTNESS;
        vec3 sunDir = getSunDirectionWorld();
        float twilight = 1.0 - smoothstep(0.0, 0.32, abs(sunDir.y));
        cloudCol += vec3(0.45, 0.15, 0.04) * (twilight * smoothstep(-0.06, 0.18, sunDir.y) * 0.25);
        return cloudCol * (cover * CLOUD_OPACITY * skyVis * (1.0 - rainStrength * 0.35));
    #else
        return vec3(0.0);
    #endif
}

vec3 waterNormal(vec3 baseNormal) {
    vec3 N = normalize(baseNormal);
    int wnId = int(vBlockId + 0.5);
    if (wnId == 1011 || wnId == 1015) return N;
    #if WAVY_WATER == 0
        return N;
    #endif
    float viewDistance = length(vWorldPos);
    float distanceFade = 1.0 / (1.0 + viewDistance * 0.035);
    float waveStrength = WATER_WAVE_STRENGTH * distanceFade;

    #if WATER_DETAIL == 0
        return N;
    #elif WATER_DETAIL == 1
        vec2 p = vWorldAbsolute.xz * 0.42;
        float t = frameTimeCounter;
        vec2 grad = vec2(
            sin(p.x * 1.35 + t * 1.15) + 0.45 * sin(p.x * 2.60 - p.y * 1.15 + t * 1.70),
            cos(p.y * 1.25 - t * 1.05) + 0.45 * cos(p.y * 2.25 + p.x * 1.00 - t * 1.45)
        );
        if (abs(N.y) > 0.6) N = normalize(vec3(grad.x * 0.075 * waveStrength, N.y, grad.y * 0.075 * waveStrength));
        return N;
    #else
        vec2 p = vWorldAbsolute.xz * 0.36 + vec2(frameTimeCounter * 0.20, frameTimeCounter * 0.145);
        float e = 0.40;
        float hC = fbm2(p);
        float hX = fbm2(p + vec2(e, 0.0));
        float hZ = fbm2(p + vec2(0.0, e));
        vec2 grad = vec2(hX - hC, hZ - hC) / e;
        if (abs(N.y) > 0.6) N = normalize(vec3(grad.x * 0.105 * waveStrength, N.y, grad.y * 0.105 * waveStrength));
        return N;
    #endif
}

void main() {
    gl_FragData[1] = vec4(0.0);
    vec4 tex = texture2D(gtexture, texcoord);
    float alpha = tex.a * vColor.a;
    if (alpha < alphaTestRef) discard;

    vec3 albedo = toLinear(tex.rgb * vColor.rgb);

    if (int(vBlockId + 0.5) == 1010) {
        float pulse = 0.92 + 0.16 * valueNoise2(vWorldAbsolute.xz * 0.35 + (WAVING_LAVA == 1 ? frameTimeCounter * 0.08 * WAVING_SPEED : 0.0));
        vec3 lava = albedo * 2.25 * pulse;
        lava = applyFog(lava, vWorldPos, vViewPos, lmcoord.y);
        gl_FragData[0] = vec4(lava, 1.0);
        return;
    }

    vec3 N = waterNormal(vWorldNormal);
    if (!gl_FrontFacing) N = -N;
    vec3 V = normalize(-vWorldPos);
    float fresnel = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);

    int waterBlockId = int(vBlockId + 0.5);
    float skyVis = pow(clamp(lmcoord.y, 0.0, 1.0), 1.50);
    #if defined(THE_END)
        skyVis = max(skyVis, 0.70);
    #endif
    bool isIce = waterBlockId == 1015;
    bool isGlass = waterBlockId == 1011;
    float reflectionFloor = isIce ? 0.18 : (isGlass ? 0.0 : 0.05);
    float reflectionFresnel = clamp(fresnel + reflectionFloor * skyVis, 0.0, 1.0);
    float reflectionStrengthHere = isIce ? ICE_REFLECTION_STRENGTH : (isGlass ? GLASS_REFLECTION_STRENGTH : WATER_REFLECTION_STRENGTH);
    if (!isIce && !isGlass) {
        albedo = applyWaterColorMode(albedo) * vec3(WATER_RED, WATER_GREEN, WATER_BLUE);
    }
    vec3 diffuse = lightSurface(albedo, N, vWorldPos, lmcoord, 0.0);
    if (isIce) diffuse *= 0.88;
    vec3 reflDir = reflect(-V, N);
    reflDir.y = abs(reflDir.y);
    #if WATER_REFLECTIONS == 0
        vec3 reflection = diffuse;
    #else
        vec3 reflection = skyGradient(reflDir) * (0.88 * skyVis) + ((isIce || isGlass) ? vec3(0.0) : auroraCloudReflection(reflDir, vWorldPos, skyVis));
    #endif

    vec3 L = getShadowLightDirectionWorld();
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 180.0) * getShadow(vWorldPos, N, lmcoord.y) * (0.25 + 1.45 * getDayFactor()) * (1.0 - rainStrength * 0.65) * reflectionStrengthHere * skyVis;

    vec3 color = mix(diffuse, reflection, clamp(reflectionFresnel * reflectionStrengthHere, 0.0, 1.0));
    color += vec3(1.00, 0.82, 0.58) * spec;
    color = applyFog(color, vWorldPos, vViewPos, lmcoord.y);

    float seeThrough = mix(1.0, 0.72, clamp(WATER_CLARITY, 0.0, 1.0) * (1.0 - fresnel));
    float outAlpha = clamp((alpha * (0.55 + 0.45 * fresnel) + fresnel * 0.35) * WATER_OPACITY * seeThrough, 0.28, 0.97);
    if (waterBlockId == 1011) {
        outAlpha = clamp(max(alpha, fresnel * GLASS_REFLECTION_STRENGTH), 0.15, 0.92);
    }
    if (isIce) {
        outAlpha = clamp(alpha, 0.90, 1.0);
    }

    #if WATER_REFLECTIONS == 0
        float reflectionWeight = 0.0;
    #else
        float reflectionWeight = isGlass ? 0.0 : clamp((isIce ? reflectionFresnel : fresnel) * reflectionStrengthHere * skyVis, 0.0, 1.0);
    #endif
    float waterMask = 0.0;
    if (isIce) {
        waterMask = reflectionWeight > 0.003 ? 0.76 + reflectionWeight * 0.24 : 0.0;
    } else if (!isGlass) {
        waterMask = max(reflectionWeight * 0.75, WATER_FOAM_STRENGTH > 0.001 ? 0.02 : 0.0);
    }
    vec3 viewNormal = normalize((gbufferModelView * vec4(N, 0.0)).xyz);
    gl_FragData[1] = vec4(viewNormal * 0.5 + 0.5, waterMask);
    gl_FragData[0] = vec4(color, outAlpha);
}
