#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform int renderStage;

varying vec2 texcoord;
varying vec4 vColor;
varying vec3 vWorldDir;

vec3 rainbowColor(float t) {
    return clamp(0.5 + 0.5 * cos(6.28318530718 * (t + vec3(0.00, 0.33, 0.67))), vec3(0.0), vec3(1.0));
}

vec3 addRainbow(vec3 color, vec3 dir) {
    #if RAINBOW_MODE == 0
        return color;
    #else
        vec3 sunDir = getSunDirectionWorld();
        float wet = RAINBOW_MODE == 2 ? 1.0 : clamp(max(rainStrength, wetness * 0.80), 0.0, 1.0);
        if (wet < 0.03 || sunDir.y < -0.03 || sunDir.y > 0.68) return color;

        float angleToAntisolar = acos(clamp(dot(dir, -sunDir), -1.0, 1.0));
        float gate = wet * getDayFactor() * smoothstep(-0.03, 0.08, dir.y) * (1.0 - smoothstep(0.45, 0.68, sunDir.y));

        float inner = 0.698;
        float outer = 0.742;
        float primaryBand = smoothstep(inner, inner + 0.012, angleToAntisolar) * (1.0 - smoothstep(outer - 0.012, outer, angleToAntisolar));
        float primaryT = clamp((angleToAntisolar - inner) / (outer - inner), 0.0, 1.0);
        color += rainbowColor(primaryT) * (primaryBand * gate * RAINBOW_INTENSITY * 0.55);

        #if RAINBOW_MODE == 2
            float inner2 = 0.881;
            float outer2 = 0.934;
            float secondaryBand = smoothstep(inner2, inner2 + 0.014, angleToAntisolar) * (1.0 - smoothstep(outer2 - 0.014, outer2, angleToAntisolar));
            float secondaryT = 1.0 - clamp((angleToAntisolar - inner2) / (outer2 - inner2), 0.0, 1.0);
            color += rainbowColor(secondaryT) * (secondaryBand * gate * RAINBOW_INTENSITY * 0.28);
        #endif

        return color;
    #endif
}

void main() {
    gl_FragData[1] = vec4(0.0);
    vec3 dir = normalize(vWorldDir);

    #if defined(PROGRAM_SKYTEXTURED)
        vec4 tex = texture2D(gtexture, texcoord) * vColor;
        if (tex.a < alphaTestRef) discard;
        vec3 texColor = toLinear(tex.rgb);
        if (renderStage == MC_RENDER_STAGE_SUN) {
            texColor *= 3.0;
        } else if (renderStage == MC_RENDER_STAGE_MOON) {
            texColor *= 1.35;
        }
        #if defined(THE_END)
            if (END_ATMOSPHERE > 0) {
                vec3 enhancedEndSky = skyGradient(dir);
                float endSkyMix = END_ATMOSPHERE == 2 ? 0.48 : 0.20;
                float endStarLum = smoothstep(0.25, 0.85, luminance(texColor));
                texColor *= 0.70 + 0.30 * clamp(STAR_AMOUNT, 0.0, 1.0);
                texColor = mix(texColor * 1.05, enhancedEndSky, endSkyMix);
                texColor += vec3(0.75, 0.82, 1.00) * (endStarLum * max(STAR_AMOUNT - 1.0, 0.0) * 0.45 * NIGHT_SKY_BRIGHTNESS);
            }
        #endif
        if (isEyeInWater == 1) texColor *= 0.35;
        gl_FragData[0] = vec4(texColor, tex.a);
        return;
    #endif

    if (renderStage == MC_RENDER_STAGE_STARS) {
        vec3 starCell = floor((dir * 0.5 + 0.5) * 220.0);
        float starHash = hash12(starCell.xy + starCell.z * 17.31);
        if (starHash > clamp(STAR_AMOUNT / 1.40, 0.0, 1.0)) discard;
        float night = 1.0 - getDayFactor();
        float starBrightness = (0.25 + 1.15 * night) * clamp(STAR_AMOUNT, 0.15, 1.60) * NIGHT_SKY_BRIGHTNESS;
        gl_FragData[0] = vec4(toLinear(vColor.rgb) * starBrightness, vColor.a);
        return;
    }

    if (renderStage == MC_RENDER_STAGE_CUSTOM_SKY || renderStage == MC_RENDER_STAGE_VOID) {
        gl_FragData[0] = vec4(toLinear(vColor.rgb), vColor.a);
        return;
    }

    if (renderStage == MC_RENDER_STAGE_SUNSET) {
        gl_FragData[0] = vec4(toLinear(vColor.rgb) * 1.20, vColor.a);
        return;
    }

    vec3 color = skyGradient(dir);
    #if defined(OVERWORLD)
        float day = getDayFactor();
        float sunDot = max(dot(dir, getSunDirectionWorld()), 0.0);
        float moonDot = max(dot(dir, getMoonDirectionWorld()), 0.0);
        color += vec3(1.00, 0.55, 0.18) * (pow(sunDot, 350.0) * 2.6 + pow(sunDot, 24.0) * 0.32) * day * (1.0 - rainStrength * 0.80);
        color += vec3(0.55, 0.65, 0.90) * pow(moonDot, 600.0) * (1.0 - day) * 0.65;
        color = mix(toLinear(fogColor), color, smoothstep(-0.08, 0.18, dir.y));
        color = addRainbow(color, dir);
    #endif

    gl_FragData[0] = vec4(color, 1.0);
}
